// Shared Database System for All Programs
// Adegan Global Enterprise - Educational Banking System

// Database Structure
const databaseStructure = {
    accounts: [],
    transactions: [],
    investments: [],
    mining: [],
    wallets: [],
    securityLogs: [],
    systemSettings: {
        owner: 'Olawale Abdul-ganiyu Adeshina',
        company: 'Adegan Global Enterprise',
        cbnLicense: 'AGB 999',
        version: '1.0.0',
        lastUpdated: new Date().toISOString()
    }
};

// Initialize Database
function initializeDatabase() {
    if (!localStorage.getItem('adeganDatabase')) {
        localStorage.setItem('adeganDatabase', JSON.stringify(databaseStructure));
        console.log('Database initialized');
    }
    return getDatabase();
}

// Get Database
function getDatabase() {
    const db = localStorage.getItem('adeganDatabase');
    return db ? JSON.parse(db) : databaseStructure;
}

// Save Database
function saveDatabase(data) {
    data.systemSettings.lastUpdated = new Date().toISOString();
    localStorage.setItem('adeganDatabase', JSON.stringify(data));
    console.log('Database saved');
}

// Account Management
function createAccount(accountData) {
    const db = getDatabase();
    
    // Generate unique identifiers
    const accountNumber = generateAccountNumber();
    const serialNumber = generateSerialNumber();
    const pin = generatePIN();
    
    const account = {
        id: generateId(),
        accountNumber: accountNumber,
        serialNumber: serialNumber,
        pin: pin,
        ...accountData,
        createdAt: new Date().toISOString(),
        status: 'pending',
        kycStatus: 'pending',
        balance: 0,
        transactions: []
    };
    
    db.accounts.push(account);
    saveDatabase(db);
    
    // Log to security
    addSecurityLog('ACCOUNT_CREATED', `Account created: ${accountNumber}`, accountData.name);
    
    return account;
}

function getAccount(accountNumber) {
    const db = getDatabase();
    return db.accounts.find(acc => acc.accountNumber === accountNumber);
}

function getAccountById(id) {
    const db = getDatabase();
    return db.accounts.find(acc => acc.id === id);
}

function updateAccount(accountId, updates) {
    const db = getDatabase();
    const accountIndex = db.accounts.findIndex(acc => acc.id === accountId);
    
    if (accountIndex !== -1) {
        db.accounts[accountIndex] = { ...db.accounts[accountIndex], ...updates };
        saveDatabase(db);
        return db.accounts[accountIndex];
    }
    return null;
}

function deleteAccount(accountId) {
    const db = getDatabase();
    db.accounts = db.accounts.filter(acc => acc.id !== accountId);
    saveDatabase(db);
}

function getAllAccounts() {
    const db = getDatabase();
    return db.accounts;
}

// Account Verification
function verifyAccount(accountNumber, nin, bvn, phone) {
    const account = getAccount(accountNumber);
    if (!account) return { success: false, message: 'Account not found' };
    
    const ninMatch = account.nin === nin;
    const bvnMatch = account.bvn === bvn;
    const phoneMatch = account.phone === phone;
    
    if (ninMatch && bvnMatch && phoneMatch) {
        updateAccount(account.id, { 
            status: 'active',
            kycStatus: 'verified',
            verifiedAt: new Date().toISOString()
        });
        return { success: true, message: 'Account verified successfully' };
    } else {
        return { 
            success: false, 
            message: 'Verification failed. Information does not match.',
            details: {
                nin: ninMatch ? '✓' : '✗',
                bvn: bvnMatch ? '✓' : '✗',
                phone: phoneMatch ? '✓' : '✗'
            }
        };
    }
}

function findAccountByPhone(phone) {
    const db = getDatabase();
    return db.accounts.find(acc => acc.phone === phone);
}

function findAccountByNIN(nin) {
    const db = getDatabase();
    return db.accounts.find(acc => acc.nin === nin);
}

function findAccountByBVN(bvn) {
    const db = getDatabase();
    return db.accounts.find(acc => acc.bvn === bvn);
}

// Transaction Management
function createTransaction(transactionData) {
    const db = getDatabase();
    
    const transaction = {
        id: generateId(),
        reference: generateReference(),
        ...transactionData,
        createdAt: new Date().toISOString(),
        status: 'completed'
    };
    
    db.transactions.push(transaction);
    
    // Update account balance
    const account = getAccount(transaction.accountNumber);
    if (account) {
        if (transaction.type === 'credit') {
            account.balance += transaction.amount;
            account.credit = (account.credit || 0) + transaction.amount;
        } else if (transaction.type === 'debit') {
            account.balance -= transaction.amount;
            account.debit = (account.debit || 0) + transaction.amount;
        }
        account.transactions.push(transaction.id);
        updateAccount(account.id, account);
    }
    
    saveDatabase(db);
    addSecurityLog('TRANSACTION', `${transaction.type.toUpperCase()}: ${formatCurrency(transaction.amount)}`, transaction.accountNumber);
    
    return transaction;
}

function getTransaction(transactionId) {
    const db = getDatabase();
    return db.transactions.find(t => t.id === transactionId);
}

function getAccountTransactions(accountNumber) {
    const db = getDatabase();
    return db.transactions.filter(t => t.accountNumber === accountNumber);
}

function getAllTransactions() {
    const db = getDatabase();
    return db.transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// Wallet Management
function createWallet(walletData) {
    const db = getDatabase();
    
    const wallet = {
        id: generateId(),
        walletAddress: generateWalletAddress(),
        barcode: generateBarcode(),
        ...walletData,
        createdAt: new Date().toISOString(),
        balance: 0
    };
    
    db.wallets.push(wallet);
    saveDatabase(db);
    
    return wallet;
}

function getWallet(walletId) {
    const db = getDatabase();
    return db.wallets.find(w => w.id === walletId);
}

function getWalletByAddress(address) {
    const db = getDatabase();
    return db.wallets.find(w => w.walletAddress === address);
}

function updateWalletBalance(walletId, amount) {
    const db = getDatabase();
    const walletIndex = db.wallets.findIndex(w => w.id === walletId);
    
    if (walletIndex !== -1) {
        db.wallets[walletIndex].balance = amount;
        saveDatabase(db);
        return db.wallets[walletIndex];
    }
    return null;
}

function getAllWallets() {
    const db = getDatabase();
    return db.wallets;
}

// Mining Management
function createMiningAccount(miningData) {
    const db = getDatabase();
    
    const mining = {
        id: generateId(),
        walletAddress: generateWalletAddress(),
        ...miningData,
        createdAt: new Date().toISOString(),
        balance: 0,
        totalMined: 0,
        miningRate: 0.000000001,
        status: 'active'
    };
    
    db.mining.push(mining);
    saveDatabase(db);
    
    return mining;
}

function updateMining(miningId, amount) {
    const db = getDatabase();
    const miningIndex = db.mining.findIndex(m => m.id === miningId);
    
    if (miningIndex !== -1) {
        db.mining[miningIndex].balance += amount;
        db.mining[miningIndex].totalMined += amount;
        saveDatabase(db);
        return db.mining[miningIndex];
    }
    return null;
}

function getMiningAccount(miningId) {
    const db = getDatabase();
    return db.mining.find(m => m.id === miningId);
}

function getAllMiningAccounts() {
    const db = getDatabase();
    return db.mining;
}

// Investment Management
function createInvestment(investmentData) {
    const db = getDatabase();
    
    const investment = {
        id: generateId(),
        serialNumber: generateSerialNumber(),
        ...investmentData,
        createdAt: new Date().toISOString(),
        status: 'active',
        currentValue: investmentData.amount,
        profit: 0,
        termYears: 5,
        endDate: calculateEndDate(investmentData.term)
    };
    
    db.investments.push(investment);
    saveDatabase(db);
    
    return investment;
}

function getInvestment(investmentId) {
    const db = getDatabase();
    return db.investments.find(i => i.id === investmentId);
}

function getAccountInvestments(accountId) {
    const db = getDatabase();
    return db.investments.filter(i => i.accountId === accountId);
}

function getAllInvestments() {
    const db = getDatabase();
    return db.investments;
}

// Security Management
function addSecurityLog(type, message, details = '') {
    const db = getDatabase();
    
    const log = {
        id: generateId(),
        type: type,
        message: message,
        details: details,
        timestamp: new Date().toISOString(),
        ip: getClientIP(),
        location: getClientLocation()
    };
    
    db.securityLogs.push(log);
    
    // Keep only last 500 logs
    if (db.securityLogs.length > 500) {
        db.securityLogs = db.securityLogs.slice(-500);
    }
    
    saveDatabase(db);
}

function getSecurityLogs() {
    const db = getDatabase();
    return db.securityLogs.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
}

// Utility Functions
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function generateAccountNumber() {
    return Math.floor(1000000000 + Math.random() * 9000000000).toString();
}

function generateSerialNumber() {
    return 'SN' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substr(2, 6).toUpperCase();
}

function generatePIN() {
    return Math.floor(1000 + Math.random() * 9000).toString();
}

function generateReference() {
    return 'REF' + Date.now().toString(36).toUpperCase();
}

function generateWalletAddress() {
    const chars = '0123456789ABCDEF';
    let address = '0x';
    for (let i = 0; i < 40; i++) {
        address += chars[Math.floor(Math.random() * chars.length)];
    }
    return address;
}

function generateBarcode() {
    return 'BC' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substr(2, 10).toUpperCase();
}

function calculateEndDate(term) {
    const now = new Date();
    const years = parseInt(term) || 5;
    now.setFullYear(now.getFullYear() + years);
    return now.toISOString();
}

function formatCurrency(amount) {
    return '₦' + parseFloat(amount).toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatCrypto(amount) {
    return parseFloat(amount).toFixed(8) + ' BTC';
}

function getClientIP() {
    return '192.168.1.' + Math.floor(Math.random() * 255);
}

function getClientLocation() {
    const locations = ['Lagos, Nigeria', 'Abuja, Nigeria', 'Ibadan, Nigeria'];
    return locations[Math.floor(Math.random() * locations.length)];
}

// System Settings
function getSystemSettings() {
    const db = getDatabase();
    return db.systemSettings;
}

function updateSystemSettings(updates) {
    const db = getDatabase();
    db.systemSettings = { ...db.systemSettings, ...updates };
    saveDatabase(db);
    return db.systemSettings;
}

// Export Database
function exportDatabase() {
    const db = getDatabase();
    const dataStr = JSON.stringify(db, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'adegan_database_export_' + new Date().toISOString().split('T')[0] + '.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Initialize on load
document.addEventListener('DOMContentLoaded', function() {
    initializeDatabase();
    console.log('Adegan Global Database System Initialized');
});

// Export functions
window.database = {
    initialize: initializeDatabase,
    get: getDatabase,
    save: saveDatabase,
    accounts: {
        create: createAccount,
        get: getAccount,
        getById: getAccountById,
        update: updateAccount,
        delete: deleteAccount,
        getAll: getAllAccounts,
        verify: verifyAccount,
        findByPhone: findAccountByPhone,
        findByNIN: findAccountByNIN,
        findByBVN: findAccountByBVN
    },
    transactions: {
        create: createTransaction,
        get: getTransaction,
        getByAccount: getAccountTransactions,
        getAll: getAllTransactions
    },
    wallets: {
        create: createWallet,
        get: getWallet,
        getByAddress: getWalletByAddress,
        updateBalance: updateWalletBalance,
        getAll: getAllWallets
    },
    mining: {
        create: createMiningAccount,
        get: getMiningAccount,
        update: updateMining,
        getAll: getAllMiningAccounts
    },
    investments: {
        create: createInvestment,
        get: getInvestment,
        getByAccount: getAccountInvestments,
        getAll: getAllInvestments
    },
    security: {
        addLog: addSecurityLog,
        getLogs: getSecurityLogs
    },
    settings: {
        get: getSystemSettings,
        update: updateSystemSettings
    },
    export: exportDatabase,
    utils: {
        formatCurrency: formatCurrency,
        formatCrypto: formatCrypto,
        generateId: generateId
    }
};