// Shared Functions for All Programs
// Adegan Global Enterprise - Educational Banking System

// Validation Functions
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePhone(phone) {
    const re = /^[\d\s\-\+\(\)]{10,20}$/;
    return re.test(phone);
}

function validateNIN(nin) {
    const re = /^\d{11}$/;
    return re.test(nin);
}

function validateBVN(bvn) {
    const re = /^\d{11}$/;
    return re.test(bvn);
}

function validateAccountNumber(accountNumber) {
    const re = /^\d{10}$/;
    return re.test(accountNumber);
}

function validateAmount(amount) {
    return !isNaN(amount) && parseFloat(amount) > 0;
}

// Security Functions
function hashPassword(password) {
    // Simple hash for demo - in production use proper hashing
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
        const char = password.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash;
    }
    return hash.toString();
}

function generateSessionToken() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function checkSession() {
    const token = sessionStorage.getItem('sessionToken');
    return token && token.length > 0;
}

function createSession(userData) {
    const token = generateSessionToken();
    sessionStorage.setItem('sessionToken', token);
    sessionStorage.setItem('userData', JSON.stringify(userData));
    return token;
}

function getSession() {
    const userData = sessionStorage.getItem('userData');
    return userData ? JSON.parse(userData) : null;
}

function destroySession() {
    sessionStorage.removeItem('sessionToken');
    sessionStorage.removeItem('userData');
}

// Alert & Notification Functions
function showSuccess(message) {
    alert('✅ ' + message);
}

function showError(message) {
    alert('❌ ' + message);
}

function showWarning(message) {
    alert('⚠️ ' + message);
}

function showInfo(message) {
    alert('ℹ️ ' + message);
}

function showModal(title, content, onConfirm) {
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>${title}</h2>
                <span class="close-btn">&times;</span>
            </div>
            <div class="modal-body">
                ${content}
            </div>
            <div class="modal-footer">
                <button class="secondary-btn" id="modalCancel">Cancel</button>
                <button class="primary-btn" id="modalConfirm">Confirm</button>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    modal.querySelector('.close-btn').onclick = () => modal.remove();
    modal.querySelector('#modalCancel').onclick = () => modal.remove();
    modal.querySelector('#modalConfirm').onclick = () => {
        if (onConfirm) onConfirm();
        modal.remove();
    };
}

// UI Functions
function showLoading() {
    const loader = document.createElement('div');
    loader.className = 'loading-overlay';
    loader.innerHTML = '<div class="loader"></div>';
    document.body.appendChild(loader);
    return loader;
}

function hideLoading(loader) {
    if (loader) loader.remove();
}

function updateElement(id, content) {
    const element = document.getElementById(id);
    if (element) {
        element.innerHTML = content;
    }
}

function getValue(id) {
    const element = document.getElementById(id);
    return element ? element.value : null;
}

function setValue(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.value = value;
    }
}

function showElement(id) {
    const element = document.getElementById(id);
    if (element) {
        element.style.display = 'block';
    }
}

function hideElement(id) {
    const element = document.getElementById(id);
    if (element) {
        element.style.display = 'none';
    }
}

function toggleElement(id) {
    const element = document.getElementById(id);
    if (element) {
        element.style.display = element.style.display === 'none' ? 'block' : 'none';
    }
}

// Format Functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-NG', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-NG', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatNumber(number) {
    return new Intl.NumberFormat('en-NG').format(number);
}

function formatCurrencyNGN(amount) {
    return new Intl.NumberFormat('en-NG', {
        style: 'currency',
        currency: 'NGN'
    }).format(amount);
}

function formatCurrencyUSD(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatPercentage(value) {
    return (value * 100).toFixed(2) + '%';
}

// Email Functions
function sendInvestmentEmail(investmentData) {
    const subject = encodeURIComponent('Investment Registration - ' + investmentData.serialNumber);
    const body = encodeURIComponent(`
INVESTMENT REGISTRATION

Personal Information:
Name: ${investmentData.name}
Email: ${investmentData.email}
Phone: ${investmentData.phone}

Investment Details:
Type: ${investmentData.type}
Amount: ${formatCurrencyNGN(investmentData.amount)}
Term: ${investmentData.term}
Serial Number: ${investmentData.serialNumber}

Registration Date: ${formatDate(investmentData.createdAt)}

Please contact me to proceed with the investment.
    `);
    
    const email = investmentData.type === 'shares' ? 'pilgrimshares@gmail.com' : 'adegan_global@gmail.com';
    window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
}

// Crypto Functions
function convertCoinToCash(coins, rate = 0.5) {
    return coins * rate;
}

function convertCashToCoin(cash, rate = 0.5) {
    return cash / rate;
}

function generateQRCode(data) {
    // This would normally use a QR code library
    // For now, return a placeholder
    return `QR_CODE:${data}`;
}

// Transaction Functions
function processTransfer(fromAccount, toAccount, amount, type = 'debit') {
    const db = window.database.get();
    
    // Check if sender has sufficient balance
    if (type === 'debit') {
        const sender = window.database.accounts.get(fromAccount);
        if (!sender || sender.balance < amount) {
            return { success: false, message: 'Insufficient balance' };
        }
    }
    
    // Create transaction
    const transaction = window.database.transactions.create({
        accountNumber: fromAccount,
        toAccount: toAccount,
        amount: amount,
        type: type,
        description: type === 'debit' ? 'Transfer Out' : 'Transfer In',
        status: 'completed'
    });
    
    return { success: true, transaction: transaction };
}

function approvePayment(transactionId) {
    const transaction = window.database.transactions.get(transactionId);
    if (transaction) {
        window.database.transactions.create({
            accountNumber: transaction.toAccount,
            fromAccount: transaction.accountNumber,
            amount: transaction.amount,
            type: 'credit',
            description: 'Received payment',
            status: 'completed'
        });
        return { success: true, message: 'Payment approved' };
    }
    return { success: false, message: 'Transaction not found' };
}

// Mining Functions
function simulateMining(miningId) {
    const mining = window.database.mining.get(miningId);
    if (mining) {
        const miningRate = mining.miningRate || 0.000000001;
        const mined = miningRate * Math.random() * 1000000;
        window.database.mining.update(miningId, mined);
        return mined;
    }
    return 0;
}

function startMiningSimulation(miningId) {
    setInterval(() => {
        const mined = simulateMining(miningId);
        if (mined > 0.00000001) {
            console.log('Mined:', formatCrypto(mined));
        }
    }, 1000); // Update every second
}

// Investment Functions
function calculateInvestmentReturn(principal, rate, years) {
    return principal * Math.pow(1 + rate, years);
}

function calculateMonthlyReturn(principal, annualRate) {
    const monthlyRate = annualRate / 12;
    return principal * monthlyRate;
}

// Security Functions
function logSecurityEvent(type, message, details) {
    window.database.security.addLog(type, message, details);
}

function detectSuspiciousActivity() {
    // Monitor for multiple failed logins
    let failedAttempts = 0;
    
    return function(activity) {
        if (activity.type === 'failed_login') {
            failedAttempts++;
            if (failedAttempts >= 3) {
                logSecurityEvent('ALERT', 'Multiple failed login attempts', 'Account locked temporarily');
                return true;
            }
        }
        return false;
    };
}

// File Upload Functions
function handleFileUpload(input, maxSizeMB = 5) {
    const file = input.files[0];
    if (!file) return null;
    
    // Check file size
    if (file.size > maxSizeMB * 1024 * 1024) {
        showError('File size exceeds ' + maxSizeMB + 'MB limit');
        return null;
    }
    
    // Check file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
        showError('Invalid file type. Only JPG, PNG, GIF, and PDF allowed');
        return null;
    }
    
    return file;
}

function readFileAsBase64(file, callback) {
    const reader = new FileReader();
    reader.onload = (e) => callback(e.target.result);
    reader.readAsDataURL(file);
}

// Navigation Functions
function navigateTo(page) {
    window.location.href = page;
}

function redirectTo(page) {
    window.location.replace(page);
}

function goBack() {
    window.history.back();
}

function refreshPage() {
    window.location.reload();
}

// Data Export Functions
function exportToCSV(data, filename) {
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).join(','));
    const csv = [headers, ...rows].join('\n');
    
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

function exportToJSON(data, filename) {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

// Date & Time Functions
function getCurrentDate() {
    return new Date().toISOString().split('T')[0];
}

function getCurrentDateTime() {
    return new Date().toISOString();
}

function addDays(date, days) {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
}

function addMonths(date, months) {
    const result = new Date(date);
    result.setMonth(result.getMonth() + months);
    return result;
}

function addYears(date, years) {
    const result = new Date(date);
    result.setFullYear(result.getFullYear() + years);
    return result;
}

// Input Validation Functions
function sanitizeInput(input) {
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
}

function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = 'red';
            isValid = false;
        } else {
            input.style.borderColor = '';
        }
    });
    
    return isValid;
}

// Localization Functions
function getLanguage() {
    return navigator.language || 'en-US';
}

function formatByLocale(number, locale = 'en-NG') {
    return new Intl.NumberFormat(locale).format(number);
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

function generateRandomString(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Initialize shared functions
window.utils = {
    validate: {
        email: validateEmail,
        phone: validatePhone,
        nin: validateNIN,
        bvn: validateBVN,
        accountNumber: validateAccountNumber,
        amount: validateAmount,
        form: validateForm
    },
    security: {
        hashPassword: hashPassword,
        createSession: createSession,
        getSession: getSession,
        destroySession: destroySession,
        checkSession: checkSession,
        logEvent: logSecurityEvent
    },
    alert: {
        success: showSuccess,
        error: showError,
        warning: showWarning,
        info: showInfo,
        modal: showModal
    },
    format: {
        date: formatDate,
        dateTime: formatDateTime,
        number: formatNumber,
        currencyNGN: formatCurrencyNGN,
        currencyUSD: formatCurrencyUSD,
        percentage: formatPercentage
    },
    crypto: {
        coinToCash: convertCoinToCash,
        cashToCoin: convertCashToCoin,
        generateQR: generateQRCode
    },
    transaction: {
        process: processTransfer,
        approve: approvePayment
    },
    mining: {
        simulate: simulateMining,
        startSimulation: startMiningSimulation
    },
    investment: {
        calculateReturn: calculateInvestmentReturn,
        calculateMonthlyReturn: calculateMonthlyReturn
    },
    file: {
        handleUpload: handleFileUpload,
        readAsBase64: readFileAsBase64
    },
    export: {
        csv: exportToCSV,
        json: exportToJSON
    },
    ui: {
        show: showElement,
        hide: hideElement,
        toggle: toggleElement,
        update: updateElement,
        getValue: getValue,
        setValue: setValue,
        loading: showLoading,
        hideLoading: hideLoading
    },
    navigation: {
        to: navigateTo,
        redirect: redirectTo,
        back: goBack,
        refresh: refreshPage
    }
};

console.log('Shared functions loaded');