// Global Bank Nigeria Customer Portal
// Adegan Global Enterprise

let currentCustomer = null;

document.addEventListener('DOMContentLoaded', function() {
    initializePortal();
});

function initializePortal() {
    detectLoginSecurityInfo();
    setupEventListeners();
}

function detectLoginSecurityInfo() {
    // Simulate location detection
    const locations = ['Lagos, Nigeria', 'Abuja, Nigeria', 'Ibadan, Nigeria'];
    document.getElementById('loginLocation').textContent = locations[Math.floor(Math.random() * locations.length)];
    
    // Simulate IP detection
    document.getElementById('loginIP').textContent = '192.168.1.' + Math.floor(Math.random() * 255);
}

function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('customerLoginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleCustomerLogin);
    }
    
    // Transfer form
    const transferForm = document.getElementById('transferForm');
    if (transferForm) {
        transferForm.addEventListener('submit', handleTransfer);
    }
    
    // Airtime form
    const airtimeForm = document.getElementById('airtimeForm');
    if (airtimeForm) {
        airtimeForm.addEventListener('submit', handleAirtime);
    }
    
    // Bill form
    const billForm = document.getElementById('billForm');
    if (billForm) {
        billForm.addEventListener('submit', handleBill);
    }
}

function handleCustomerLogin(e) {
    e.preventDefault();
    
    const accountNumber = document.getElementById('loginAccountNumber').value;
    const pin = document.getElementById('loginPIN').value;
    
    // Validate input
    if (!utils.validate.accountNumber(accountNumber)) {
        utils.alert.error('Invalid account number format');
        return;
    }
    
    if (pin.length !== 4) {
        utils.alert.error('PIN must be 4 digits');
        return;
    }
    
    // Find account
    const account = window.database.accounts.get(accountNumber);
    
    if (!account) {
        utils.alert.error('Account not found. Please contact admin.');
        window.database.security.addLog('LOGIN_FAILED', 'Invalid account number', accountNumber);
        return;
    }
    
    if (account.pin !== pin) {
        utils.alert.error('Invalid PIN');
        window.database.security.addLog('LOGIN_FAILED', 'Invalid PIN attempt', accountNumber);
        return;
    }
    
    if (account.status !== 'active') {
        utils.alert.error('Account is not active. Status: ' + account.status);
        window.database.security.addLog('LOGIN_FAILED', 'Account not active', accountNumber);
        return;
    }
    
    // Login successful
    currentCustomer = account;
    window.database.security.addLog('LOGIN_SUCCESS', 'Customer logged in', accountNumber);
    
    showDashboard();
}

function showDashboard() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'block';
    
    // Update customer info
    document.getElementById('customerName').textContent = currentCustomer.name;
    document.getElementById('accountNumber').textContent = currentCustomer.accountNumber;
    document.getElementById('accountType').textContent = currentCustomer.accountType;
    document.getElementById('availableBalance').textContent = utils.format.currencyNGN(currentCustomer.balance || 0);
    
    // Start date/time update
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    // Load transaction history
    loadTransactionHistory();
}

function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const dateTimeElement = document.getElementById('currentDateTime');
    if (dateTimeElement) {
        dateTimeElement.textContent = now.toLocaleDateString('en-NG', options);
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show selected section
    document.getElementById(sectionId + 'Section').style.display = 'block';
}

function handleTransfer(e) {
    e.preventDefault();
    
    const transferType = document.getElementById('transferType').value;
    const recipientAccount = document.getElementById('recipientAccount').value;
    const recipientName = document.getElementById('recipientName').value;
    const recipientBank = document.getElementById('recipientBank').value;
    const amount = parseFloat(document.getElementById('transferAmount').value);
    const description = document.getElementById('transferDescription').value || 'Transfer';
    
    // Check balance
    if (currentCustomer.balance < amount) {
        utils.alert.error('Insufficient balance');
        return;
    }
    
    // Process transfer based on type
    if (transferType === 'local' || transferType === 'international') {
        // Debit customer account
        window.database.transactions.create({
            accountNumber: currentCustomer.accountNumber,
            toAccount: recipientAccount,
            amount: amount,
            type: 'debit',
            description: `${transferType} transfer to ${recipientName}`,
            transferType: transferType,
            recipientName: recipientName,
            recipientBank: recipientBank,
            status: 'completed'
        });
        
        // Update local customer balance
        const updatedCustomer = window.database.accounts.get(currentCustomer.accountNumber);
        currentCustomer = updatedCustomer;
        document.getElementById('availableBalance').textContent = utils.format.currencyNGN(currentCustomer.balance || 0);
        
        utils.alert.success(`Transfer of ${utils.format.currencyNGN(amount)} to ${recipientName} successful!`);
    } else if (transferType === 'pilgrim') {
        // Transfer to Pilgrim Coin
        utils.alert.info('Pilgrim Coin transfer - Opening Pilgrim Coin portal...');
        setTimeout(() => {
            window.location.href = '../pilgrim-coin/index.html';
        }, 2000);
    } else if (transferType === 'wallet') {
        // Wallet transfer
        utils.alert.info('Wallet transfer - Opening wallet portal...');
        setTimeout(() => {
            window.location.href = '../pilgrim-wallet/index.html';
        }, 2000);
    }
    
    // Reset form
    document.getElementById('transferForm').reset();
    
    // Reload transaction history
    loadTransactionHistory();
}

function handleAirtime(e) {
    e.preventDefault();
    
    const network = document.getElementById('airtimeNetwork').value;
    const phone = document.getElementById('airtimePhone').value;
    const amount = parseFloat(document.getElementById('airtimeAmount').value);
    
    // Check balance
    if (currentCustomer.balance < amount) {
        utils.alert.error('Insufficient balance');
        return;
    }
    
    // Process airtime purchase
    window.database.transactions.create({
        accountNumber: currentCustomer.accountNumber,
        amount: amount,
        type: 'debit',
        description: `Airtime purchase - ${network.toUpperCase()} - ${phone}`,
        status: 'completed'
    });
    
    // Update balance
    const updatedCustomer = window.database.accounts.get(currentCustomer.accountNumber);
    currentCustomer = updatedCustomer;
    document.getElementById('availableBalance').textContent = utils.format.currencyNGN(currentCustomer.balance || 0);
    
    utils.alert.success(`Airtime of ${utils.format.currencyNGN(amount)} purchased for ${phone}`);
    
    document.getElementById('airtimeForm').reset();
    loadTransactionHistory();
}

function handleBill(e) {
    e.preventDefault();
    
    const billType = document.getElementById('billType').value;
    const provider = document.getElementById('billProvider').value;
    const customerNumber = document.getElementById('customerNumber').value;
    const amount = parseFloat(document.getElementById('billAmount').value);
    
    // Check balance
    if (currentCustomer.balance < amount) {
        utils.alert.error('Insufficient balance');
        return;
    }
    
    // Process bill payment
    window.database.transactions.create({
        accountNumber: currentCustomer.accountNumber,
        amount: amount,
        type: 'debit',
        description: `${billType} payment - ${provider} - ${customerNumber}`,
        status: 'completed'
    });
    
    // Update balance
    const updatedCustomer = window.database.accounts.get(currentCustomer.accountNumber);
    currentCustomer = updatedCustomer;
    document.getElementById('availableBalance').textContent = utils.format.currencyNGN(currentCustomer.balance || 0);
    
    utils.alert.success(`Bill payment of ${utils.format.currencyNGN(amount)} successful`);
    
    document.getElementById('billForm').reset();
    loadTransactionHistory();
}

function loadTransactionHistory() {
    const db = window.database.get();
    const filter = document.getElementById('historyFilter').value;
    
    let transactions = db.transactions.filter(t => 
        t.accountNumber === currentCustomer.accountNumber
    );
    
    // Apply filter
    if (filter !== 'all') {
        transactions = transactions.filter(t => t.type === filter);
    }
    
    // Sort by date (newest first)
    transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const transactionsDiv = document.getElementById('transactionList');
    if (!transactionsDiv) return;
    
    if (transactions.length === 0) {
        transactionsDiv.innerHTML = '<p class="no-data">No transactions found</p>';
        return;
    }
    
    transactionsDiv.innerHTML = `
        <div class="transactions-table">
            ${transactions.map(t => `
                <div class="transaction-item ${t.type}">
                    <div class="transaction-info">
                        <div class="transaction-type">
                            <strong>${t.type === 'credit' ? 'Received' : 'Sent'}</strong>
                            <small>${utils.format.dateTime(t.createdAt)}</small>
                        </div>
                        <div class="transaction-description">${t.description}</div>
                    </div>
                    <div class="transaction-amount">
                        ${t.type === 'credit' ? '+' : '-'}${utils.format.currencyNGN(t.amount)}
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.database.security.addLog('LOGOUT', 'Customer logged out', currentCustomer.accountNumber);
        currentCustomer = null;
        document.getElementById('dashboardSection').style.display = 'none';
        document.getElementById('loginSection').style.display = 'block';
        document.getElementById('customerLoginForm').reset();
    }
}