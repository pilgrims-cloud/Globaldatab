// Pilgrim Investment & Shares Platform
// Adegan Global Enterprise

document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
});

function initializeDashboard() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    loadDashboardStats();
    loadPortfolio();
    loadShares();
    loadInvestments();
    loadHistory();
    
    setupEventListeners();
    updateInvestmentSummary();
}

function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    const dateTimeElement = document.getElementById('currentDateTime');
    if (dateTimeElement) {
        dateTimeElement.textContent = now.toLocaleDateString('en-NG', options);
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
    
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Load section-specific data
    if (sectionId === 'portfolio') loadPortfolio();
    if (sectionId === 'shares') loadShares();
    if (sectionId === 'investments') loadInvestments();
    if (sectionId === 'history') loadHistory();
}

function setupEventListeners() {
    // Investment form
    const investmentForm = document.getElementById('investmentForm');
    if (investmentForm) {
        investmentForm.addEventListener('submit', handleInvestmentRegistration);
    }
    
    // Investment amount change
    const investmentAmount = document.getElementById('investmentAmount');
    if (investmentAmount) {
        investmentAmount.addEventListener('input', updateInvestmentSummary);
    }
    
    // Investment type change
    const investmentType = document.getElementById('investmentType');
    if (investmentType) {
        investmentType.addEventListener('change', updateInvestmentEmail);
    }
    
    // Investment term change
    const investmentTerm = document.getElementById('investmentTerm');
    if (investmentTerm) {
        investmentTerm.addEventListener('change', updateInvestmentSummary);
    }
}

function loadDashboardStats() {
    const db = window.database.get();
    const investments = db.investments;
    
    // Total investments
    document.getElementById('totalInvestments').textContent = investments.length;
    
    // Total value
    const totalValue = investments.reduce((sum, inv) => sum + inv.currentValue, 0);
    document.getElementById('totalValue').textContent = utils.format.currencyNGN(totalValue);
    
    // Total shares
    const totalShares = investments
        .filter(inv => inv.type === 'shares')
        .reduce((sum, inv) => sum + (inv.shares || 0), 0);
    document.getElementById('totalShares').textContent = totalShares;
    
    // Total profit
    const totalProfit = investments.reduce((sum, inv) => sum + inv.profit, 0);
    document.getElementById('totalProfit').textContent = utils.format.currencyNGN(totalProfit);
}

function updateInvestmentEmail() {
    const type = document.getElementById('investmentType').value;
    const emailElement = document.getElementById('summaryEmail');
    const summaryTypeElement = document.getElementById('summaryType');
    
    if (type === 'shares') {
        emailElement.textContent = 'pilgrimshares@gmail.com';
        summaryTypeElement.textContent = 'Shares';
    } else {
        emailElement.textContent = 'adegan_global@gmail.com';
        summaryTypeElement.textContent = 'Investment';
    }
}

function updateInvestmentSummary() {
    const type = document.getElementById('investmentType').value;
    const term = document.getElementById('investmentTerm').value;
    const amount = parseFloat(document.getElementById('investmentAmount').value) || 0;
    const duration = document.getElementById('investmentDuration').value;
    
    // Update summary
    document.getElementById('summaryType').textContent = type === 'shares' ? 'Shares' : 'Investment';
    document.getElementById('summaryTerm').textContent = term === 'monthly' ? 'Monthly' : 'Annual';
    document.getElementById('summaryAmount').textContent = utils.format.currencyNGN(amount);
    document.getElementById('summaryDuration').textContent = duration + ' Years';
    
    // Calculate expected return
    let expectedReturn = 0;
    const rate = term === 'monthly' ? 0.10 : 0.15; // 10% monthly, 15% annual
    
    if (term === 'monthly') {
        const monthlyReturn = amount * rate;
        expectedReturn = monthlyReturn * 12 * parseInt(duration);
    } else {
        expectedReturn = amount * rate * parseInt(duration);
    }
    
    document.getElementById('summaryReturn').textContent = utils.format.currencyNGN(expectedReturn);
}

function sendInvestmentEmail() {
    const name = document.getElementById('investorName').value;
    const email = document.getElementById('investorEmail').value;
    const phone = document.getElementById('investorPhone').value;
    const type = document.getElementById('investmentType').value;
    const term = document.getElementById('investmentTerm').value;
    const amount = document.getElementById('investmentAmount').value;
    
    if (!name || !email || !phone || !amount) {
        utils.alert.error('Please fill all required fields');
        return;
    }
    
    // Generate serial number
    const serialNumber = 'INV' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).substr(2, 6).toUpperCase();
    
    const investmentData = {
        name: name,
        email: email,
        phone: phone,
        address: document.getElementById('investorAddress').value,
        type: type,
        term: term,
        amount: parseFloat(amount),
        duration: parseInt(document.getElementById('investmentDuration').value),
        serialNumber: serialNumber,
        createdAt: new Date().toISOString()
    };
    
    utils.investment.sendEmail(investmentData);
}

function handleInvestmentRegistration(e) {
    e.preventDefault();
    
    const name = document.getElementById('investorName').value;
    const email = document.getElementById('investorEmail').value;
    const phone = document.getElementById('investorPhone').value;
    const address = document.getElementById('investorAddress').value;
    const type = document.getElementById('investmentType').value;
    const term = document.getElementById('investmentTerm').value;
    const amount = parseFloat(document.getElementById('investmentAmount').value);
    const duration = parseInt(document.getElementById('investmentDuration').value);
    
    // Calculate shares for share type
    let shares = 0;
    if (type === 'shares') {
        shares = Math.floor(amount / 1000); // 1 share per ₦1,000
    }
    
    // Create investment
    const investmentData = {
        investorName: name,
        email: email,
        phone: phone,
        address: address,
        type: type,
        term: term,
        amount: amount,
        duration: duration,
        shares: shares,
        status: 'active'
    };
    
    const investment = window.database.investments.create(investmentData);
    
    utils.alert.success(`Investment registered successfully!\n\nSerial Number: ${investment.serialNumber}\nAmount: ${utils.format.currencyNGN(amount)}\nType: ${type}\nTerm: ${term}\nDuration: ${duration} years\n${type === 'shares' ? `Shares: ${shares}\n` : ''}Please send registration email to complete process.`);
    
    resetForm();
    loadDashboardStats();
    loadPortfolio();
}

function loadPortfolio() {
    const db = window.database.get();
    const investments = db.investments.filter(inv => inv.status === 'active');
    
    const portfolioDiv = document.getElementById('portfolioList');
    if (!portfolioDiv) return;
    
    if (investments.length === 0) {
        portfolioDiv.innerHTML = '<p class="no-data">No investments found</p>';
        return;
    }
    
    portfolioDiv.innerHTML = investments.map(inv => {
        const endDate = new Date(inv.endDate);
        const now = new Date();
        const yearsRemaining = Math.max(0, Math.ceil((endDate - now) / (365.25 * 24 * 60 * 60 * 1000)));
        const roi = ((inv.currentValue - inv.amount) / inv.amount * 100).toFixed(2);
        
        return `
            <div class="portfolio-card">
                <div class="portfolio-header">
                    <h3>${inv.investorName}</h3>
                    <span class="badge ${inv.type === 'shares' ? 'info' : 'success'}">${inv.type}</span>
                </div>
                <div class="portfolio-details">
                    <p><strong>Serial Number:</strong> ${inv.serialNumber}</p>
                    <p><strong>Type:</strong> ${inv.type} (${inv.term})</p>
                    <p><strong>Initial Amount:</strong> ${utils.format.currencyNGN(inv.amount)}</p>
                    <p><strong>Current Value:</strong> ${utils.format.currencyNGN(inv.currentValue)}</p>
                    <p><strong>Profit:</strong> ${utils.format.currencyNGN(inv.profit)} (${roi}%)</p>
                    <p><strong>Years Remaining:</strong> ${yearsRemaining} / ${inv.duration}</p>
                    ${inv.shares ? `<p><strong>Shares:</strong> ${inv.shares}</p>` : ''}
                    <p><strong>End Date:</strong> ${utils.format.date(inv.endDate)}</p>
                </div>
            </div>
        `;
    }).join('');
}

function loadShares() {
    const db = window.database.get();
    const shares = db.investments.filter(inv => inv.type === 'shares' && inv.status === 'active');
    
    const sharesDiv = document.getElementById('sharesList');
    if (!sharesDiv) return;
    
    if (shares.length === 0) {
        sharesDiv.innerHTML = '<p class="no-data">No shares found</p>';
        return;
    }
    
    sharesDiv.innerHTML = shares.map(inv => `
        <div class="share-card">
            <div class="share-header">
                <h3>${inv.investorName}</h3>
                <span class="badge info">${inv.shares} Shares</span>
            </div>
            <div class="share-details">
                <p><strong>Serial Number:</strong> ${inv.serialNumber}</p>
                <p><strong>Shares Owned:</strong> ${inv.shares}</p>
                <p><strong>Value per Share:</strong> ₦1,000.00</p>
                <p><strong>Total Value:</strong> ${utils.format.currencyNGN(inv.currentValue)}</p>
                <p><strong>Profit:</strong> ${utils.format.currencyNGN(inv.profit)}</p>
                <p><strong>Term:</strong> ${inv.term}</p>
            </div>
        </div>
    `).join('');
}

function loadInvestments() {
    const db = window.database.get();
    const investments = db.investments.filter(inv => inv.type === 'investment' && inv.status === 'active');
    
    const investmentsDiv = document.getElementById('investmentsList');
    if (!investmentsDiv) return;
    
    if (investments.length === 0) {
        investmentsDiv.innerHTML = '<p class="no-data">No investments found</p>';
        return;
    }
    
    investmentsDiv.innerHTML = investments.map(inv => {
        const endDate = new Date(inv.endDate);
        const now = new Date();
        const daysRemaining = Math.max(0, Math.ceil((endDate - now) / (24 * 60 * 60 * 1000)));
        
        return `
            <div class="investment-card">
                <div class="investment-header">
                    <h3>${inv.investorName}</h3>
                    <span class="badge success">${inv.term}</span>
                </div>
                <div class="investment-details">
                    <p><strong>Serial Number:</strong> ${inv.serialNumber}</p>
                    <p><strong>Initial Amount:</strong> ${utils.format.currencyNGN(inv.amount)}</p>
                    <p><strong>Current Value:</strong> ${utils.format.currencyNGN(inv.currentValue)}</p>
                    <p><strong>Profit:</strong> ${utils.format.currencyNGN(inv.profit)}</p>
                    <p><strong>Days Remaining:</strong> ${daysRemaining}</p>
                    <p><strong>Start Date:</strong> ${utils.format.date(inv.createdAt)}</p>
                    <p><strong>End Date:</strong> ${utils.format.date(inv.endDate)}</p>
                </div>
            </div>
        `;
    }).join('');
}

function loadHistory() {
    const db = window.database.get();
    const investments = db.investments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const historyDiv = document.getElementById('historyList');
    if (!historyDiv) return;
    
    if (investments.length === 0) {
        historyDiv.innerHTML = '<p class="no-data">No transactions found</p>';
        return;
    }
    
    historyDiv.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Investor</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Current Value</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${investments.map(inv => `
                    <tr>
                        <td>${utils.format.dateTime(inv.createdAt)}</td>
                        <td>${inv.investorName}</td>
                        <td><span class="badge ${inv.type === 'shares' ? 'info' : 'success'}">${inv.type}</span></td>
                        <td>${utils.format.currencyNGN(inv.amount)}</td>
                        <td>${utils.format.currencyNGN(inv.currentValue)}</td>
                        <td><span class="badge ${inv.status === 'active' ? 'success' : 'warning'}">${inv.status}</span></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function resetForm() {
    document.getElementById('investmentForm').reset();
    updateInvestmentSummary();
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = '../index.html';
    }
}