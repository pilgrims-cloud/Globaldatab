// Global Bank Nigeria & Pilgrim Coin/Cash Dashboard
// Owner: Olawale Abdul-ganiyu Adeshina

// Initialize Application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Admin Credentials
const ADMIN_CREDENTIALS = {
    username: 'admin',
    password: 'admin123' // Default admin password
};

// Application State
let appState = {
    isLoggedIn: false,
    currentUser: null,
    accounts: [],
    transactions: [],
    linkedBanks: [],
    securityLogs: [],
    connections: [],
    loginAttempts: 0,
    adminPassword: 'admin123' // Can be changed by admin
};

// Initialize Application
function initializeApp() {
    // Load data from localStorage
    loadFromStorage();
    
    // Check if on login page or dashboard
    if (window.location.pathname.includes('dashboard.html')) {
        if (!appState.isLoggedIn) {
            window.location.href = 'index.html';
            return;
        }
        initializeDashboard();
    } else {
        initializeLoginPage();
    }
}

// Initialize Login Page
function initializeLoginPage() {
    // Detect and display security information
    detectSecurityInfo();
    
    // Setup login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Monitor for suspicious activity
    monitorSecurity();
}

// Detect Security Information
function detectSecurityInfo() {
    // Get IP Address (simulated for demo)
    const ipAddress = '192.168.1.' + Math.floor(Math.random() * 255);
    document.getElementById('ipAddress').textContent = ipAddress;
    
    // Get Location (simulated)
    const locations = ['Lagos, Nigeria', 'Abuja, Nigeria', 'Ibadan, Nigeria', 'Port Harcourt, Nigeria'];
    const location = locations[Math.floor(Math.random() * locations.length)];
    document.getElementById('location').textContent = location;
    
    // Get Signal Strength
    const signals = ['Excellent (4G)', 'Good (3G)', 'Strong (WiFi)', 'Stable (LTE)'];
    const signal = signals[Math.floor(Math.random() * signals.length)];
    document.getElementById('signalStrength').textContent = signal;
    
    // Get Connection Type
    const connectionTypes = ['Secure HTTPS', 'HTTP Standard', 'Encrypted VPN', 'Direct Satellite'];
    const connectionType = connectionTypes[Math.floor(Math.random() * connectionTypes.length)];
    document.getElementById('connectionType').textContent = connectionType;
}

// Monitor Security
function monitorSecurity() {
    // Log login page access
    addSecurityLog('INFO', 'Login page accessed', 'IP: ' + document.getElementById('ipAddress').textContent);
    
    // Monitor for suspicious activities
    let activityTimeout;
    document.addEventListener('mousemove', () => {
        clearTimeout(activityTimeout);
        activityTimeout = setTimeout(() => {
            addSecurityLog('WARNING', 'User inactive for 5 minutes', 'Potential security concern');
        }, 300000); // 5 minutes
    });
    
    // Prevent right-click for security
    document.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        addSecurityLog('WARNING', 'Right-click attempt blocked', 'Potential data copy attempt');
    });
}

// Handle Login
function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Validate credentials
    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
        appState.isLoggedIn = true;
        appState.currentUser = username;
        appState.loginAttempts = 0;
        
        // Log successful login
        addSecurityLog('SUCCESS', 'Admin logged in successfully', 'User: ' + username);
        
        // Save state and redirect
        saveToStorage();
        window.location.href = 'dashboard.html';
    } else {
        appState.loginAttempts++;
        
        // Log failed login attempt
        addSecurityLog('ALERT', 'Failed login attempt', 'User: ' + username + ' | Attempt: ' + appState.loginAttempts);
        
        // Show security alert
        showSecurityAlert('Invalid credentials! Attempt ' + appState.loginAttempts + ' recorded.');
        
        // Reset form
        document.getElementById('username').value = '';
        document.getElementById('password').value = '';
        
        // Save state
        saveToStorage();
        
        // Lock account after 3 failed attempts
        if (appState.loginAttempts >= 3) {
            showSecurityAlert('Account locked due to multiple failed attempts. Contact administrator.');
            document.getElementById('loginForm').disabled = true;
            setTimeout(() => {
                appState.loginAttempts = 0;
                saveToStorage();
                location.reload();
            }, 30000); // 30 seconds lockout
        }
    }
}

// Show Security Alert
function showSecurityAlert(message) {
    const alertDiv = document.getElementById('securityAlert');
    const messageDiv = document.getElementById('alertMessage');
    
    messageDiv.textContent = message;
    alertDiv.style.display = 'block';
    
    setTimeout(() => {
        alertDiv.style.display = 'none';
    }, 5000);
}

// Initialize Dashboard
function initializeDashboard() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    updateDashboardStats();
    loadAccounts();
    loadLinkedBanks();
    loadTransactions();
    updateSecurityInfo();
    
    // Monitor connections
    monitorConnections();
    
    // Setup form listeners
    setupFormListeners();
}

// Update Date/Time
function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const dateTimeStr = now.toLocaleDateString('en-US', options);
    
    const dateTimeElement = document.getElementById('currentDateTime');
    if (dateTimeElement) {
        dateTimeElement.textContent = dateTimeStr;
    }
}

// Update Dashboard Stats
function updateDashboardStats() {
    // Global Bank Stats
    const globalAccounts = appState.accounts.filter(acc => acc.type === 'global');
    document.getElementById('globalBankCount').textContent = globalAccounts.length;
    
    const globalTotal = globalAccounts.reduce((sum, acc) => sum + acc.cash, 0);
    document.getElementById('globalBankTotal').textContent = formatCurrency(globalTotal);
    
    // Pilgrim Stats
    const pilgrimAccounts = appState.accounts.filter(acc => acc.type === 'pilgrim');
    document.getElementById('pilgrimCount').textContent = pilgrimAccounts.length;
    
    const pilgrimTotal = pilgrimAccounts.reduce((sum, acc) => sum + (acc.cash + acc.coins), 0);
    document.getElementById('pilgrimTotal').textContent = formatCurrency(pilgrimTotal);
    
    // Transactions Today
    const today = new Date().toDateString();
    const todayTransactions = appState.transactions.filter(t => 
        new Date(t.date).toDateString() === today
    );
    document.getElementById('totalTransactions').textContent = todayTransactions.length;
    
    // Update security stats
    document.getElementById('loginAttempts').textContent = appState.loginAttempts;
    document.getElementById('securityAlertsCount').textContent = appState.securityLogs.filter(
        log => log.type === 'ALERT' || log.type === 'WARNING'
    ).length;
    
    // Load recent activity
    loadRecentActivity();
}

// Load Recent Activity
function loadRecentActivity() {
    const recentActivity = document.getElementById('recentActivity');
    if (!recentActivity) return;
    
    const recentTransactions = appState.transactions
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 5);
    
    if (recentTransactions.length === 0) {
        recentActivity.innerHTML = '<p>No recent activity</p>';
        return;
    }
    
    recentActivity.innerHTML = recentTransactions.map(t => `
        <div class="activity-item">
            <div>
                <strong>${t.type === 'credit' ? 'Credit' : 'Debit'}</strong>
                <p>${t.description}</p>
            </div>
            <div class="transaction-amount ${t.type}">
                ${t.type === 'credit' ? '+' : '-'}${formatCurrency(t.amount)}
            </div>
        </div>
    `).join('');
}

// Update Security Info
function updateSecurityInfo() {
    const ip = '192.168.1.' + Math.floor(Math.random() * 255);
    const dashIP = document.getElementById('dashIP');
    if (dashIP) {
        dashIP.textContent = ip;
    }
    
    const signals = ['Excellent', 'Good', 'Strong', 'Stable'];
    const signal = signals[Math.floor(Math.random() * signals.length)];
    const dashSignal = document.getElementById('dashSignal');
    if (dashSignal) {
        dashSignal.textContent = signal;
    }
}

// Monitor Connections
function monitorConnections() {
    // Simulate connection monitoring
    const connectionTypes = ['HTTPS Secure', 'HTTP Standard', 'VPN Encrypted', 'Satellite Link'];
    
    // Log current connection
    const currentConnection = {
        id: Date.now(),
        type: connectionTypes[Math.floor(Math.random() * connectionTypes.length)],
        ip: '192.168.1.' + Math.floor(Math.random() * 255),
        location: 'Lagos, Nigeria',
        status: 'Active',
        timestamp: new Date().toISOString()
    };
    
    if (appState.connections.length === 0) {
        appState.connections.push(currentConnection);
        addSecurityLog('INFO', 'New connection established', currentConnection.type);
    }
    
    updateConnectionsList();
    
    // Monitor for connection changes
    setInterval(() => {
        // Simulate connection check
        addSecurityLog('INFO', 'Connection verified', 'All systems operational');
    }, 60000); // Every minute
}

// Update Connections List
function updateConnectionsList() {
    const connectionsList = document.getElementById('connectionsList');
    if (!connectionsList) return;
    
    if (appState.connections.length === 0) {
        connectionsList.innerHTML = '<p class="no-connections">No active connections</p>';
        return;
    }
    
    connectionsList.innerHTML = appState.connections.map(conn => `
        <div class="connection-item">
            <div>
                <strong>${conn.type}</strong>
                <p>IP: ${conn.ip} | ${conn.location}</p>
            </div>
            <div>
                <span class="bank-status connected">${conn.status}</span>
                <button onclick="terminateConnection(${conn.id})" class="delete-btn" style="margin-left: 10px;">Terminate</button>
            </div>
        </div>
    `).join('');
}

// Terminate Connection
function terminateConnection(connId) {
    const password = prompt('Enter admin password to terminate connection:');
    
    if (password !== appState.adminPassword) {
        alert('Invalid password!');
        addSecurityLog('ALERT', 'Unauthorized connection termination attempt', 'Invalid password provided');
        return;
    }
    
    appState.connections = appState.connections.filter(c => c.id !== connId);
    addSecurityLog('SUCCESS', 'Connection terminated', 'Connection ID: ' + connId);
    saveToStorage();
    updateConnectionsList();
}

// Setup Form Listeners
function setupFormListeners() {
    // New Account Form
    const newAccountForm = document.getElementById('newAccountForm');
    if (newAccountForm) {
        newAccountForm.addEventListener('submit', handleNewAccount);
    }
    
    // Edit Account Form
    const editAccountForm = document.getElementById('editAccountForm');
    if (editAccountForm) {
        editAccountForm.addEventListener('submit', handleEditAccount);
    }
    
    // Outgoing Payment Form
    const outgoingPaymentForm = document.getElementById('outgoingPaymentForm');
    if (outgoingPaymentForm) {
        outgoingPaymentForm.addEventListener('submit', handleOutgoingPayment);
    }
    
    // Bank Link Form
    const bankLinkForm = document.getElementById('bankLinkForm');
    if (bankLinkForm) {
        bankLinkForm.addEventListener('submit', handleBankLink);
    }
    
    // Delete Confirmation Form
    const deleteConfirmForm = document.getElementById('deleteConfirmForm');
    if (deleteConfirmForm) {
        deleteConfirmForm.addEventListener('submit', handleDeleteConfirm);
    }
}

// Show/Hide Sections
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
    
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Update specific sections
    if (sectionId === 'accounts') {
        loadAccounts();
    } else if (sectionId === 'payments') {
        updatePaymentAccountSelects();
    } else if (sectionId === 'security') {
        updateSecurityLogs();
    }
}

// Account Management Functions
function loadAccounts() {
    const accountsList = document.getElementById('accountsList');
    if (!accountsList) return;
    
    const filter = document.getElementById('accountFilter');
    const search = document.getElementById('accountSearch');
    
    let filteredAccounts = [...appState.accounts];
    
    // Apply filter
    if (filter && filter.value !== 'all') {
        filteredAccounts = filteredAccounts.filter(acc => acc.type === filter.value);
    }
    
    // Apply search
    if (search && search.value) {
        const searchTerm = search.value.toLowerCase();
        filteredAccounts = filteredAccounts.filter(acc =>
            acc.name.toLowerCase().includes(searchTerm) ||
            acc.accountNumber.includes(searchTerm) ||
            acc.email.toLowerCase().includes(searchTerm)
        );
    }
    
    if (filteredAccounts.length === 0) {
        accountsList.innerHTML = '<p class="no-accounts">No accounts found</p>';
        return;
    }
    
    accountsList.innerHTML = filteredAccounts.map(acc => `
        <div class="account-card ${acc.type}">
            <div class="account-header">
                <span class="account-type">${acc.type === 'global' ? 'Global Bank' : 'Pilgrim Coin'}</span>
                <span class="status-indicator active">Active</span>
            </div>
            <div class="account-details">
                <p><strong>Account Number:</strong> ${acc.accountNumber}</p>
                <p><strong>Serial Number:</strong> ${acc.serialNumber}</p>
                <p><strong>Name:</strong> ${acc.name}</p>
                <p><strong>Age:</strong> ${acc.age}</p>
                <p><strong>Email:</strong> ${acc.email}</p>
                <p><strong>Registered:</strong> ${new Date(acc.registrationDate).toLocaleDateString()}</p>
            </div>
            <div class="balance-display">
                <div class="balance-item">
                    <span>Cash Balance:</span>
                    <strong>${formatCurrency(acc.cash)}</strong>
                </div>
                <div class="balance-item">
                    <span>Coin Balance:</span>
                    <strong>${acc.coins} coins</strong>
                </div>
                <div class="balance-item">
                    <span>Total:</span>
                    <strong>${formatCurrency(acc.cash + acc.coins)}</strong>
                </div>
            </div>
            <div class="account-actions">
                ${acc.isEdited ? 
                    '<button class="edit-btn" disabled>Edited (Read-only)</button>' :
                    `<button class="edit-btn" onclick="editAccount('${acc.id}')">Edit Account</button>`
                }
                <button class="delete-btn" onclick="deleteAccount('${acc.id}')">Delete</button>
            </div>
        </div>
    `).join('');
}

function showAddAccountForm() {
    document.getElementById('addAccountForm').style.display = 'flex';
}

function hideAddAccountForm() {
    document.getElementById('addAccountForm').style.display = 'none';
    document.getElementById('newAccountForm').reset();
}

function handleNewAccount(e) {
    e.preventDefault();
    
    const profilePhotoInput = document.getElementById('profilePhoto');
    const documentPhotoInput = document.getElementById('documentPhoto');
    
    const newAccount = {
        id: generateId(),
        type: document.getElementById('accountType').value,
        accountNumber: document.getElementById('accountNumber').value,
        serialNumber: document.getElementById('serialNumber').value,
        name: document.getElementById('fullName').value,
        age: parseInt(document.getElementById('age').value),
        email: document.getElementById('email').value,
        cash: parseFloat(document.getElementById('initialCash').value) || 0,
        coins: parseFloat(document.getElementById('initialCoins').value) || 0,
        registrationDate: new Date().toISOString(),
        profilePhoto: profilePhotoInput.files[0] ? 'data:image/jpeg;base64,' + 'placeholder' : null,
        documentPhoto: documentPhotoInput.files[0] ? 'data:image/jpeg;base64,' + 'placeholder' : null,
        isEdited: false,
        debit: 0,
        credit: 0
    };
    
    appState.accounts.push(newAccount);
    addSecurityLog('SUCCESS', 'New account created', 'Account: ' + newAccount.accountNumber);
    saveToStorage();
    
    hideAddAccountForm();
    loadAccounts();
    updateDashboardStats();
    
    alert('Account created successfully!');
}

function editAccount(accountId) {
    const account = appState.accounts.find(acc => acc.id === accountId);
    if (!account) return;
    
    if (account.isEdited) {
        alert('This account has already been edited. No further edits allowed.');
        return;
    }
    
    document.getElementById('editAccountId').value = account.id;
    document.getElementById('editAccountNumber').value = account.accountNumber;
    document.getElementById('editFullName').value = account.name;
    document.getElementById('editEmail').value = account.email;
    document.getElementById('editCash').value = account.cash;
    document.getElementById('editCoins').value = account.coins;
    
    document.getElementById('editModal').style.display = 'flex';
}

function hideEditModal() {
    document.getElementById('editModal').style.display = 'none';
    document.getElementById('editAccountForm').reset();
}

function handleEditAccount(e) {
    e.preventDefault();
    
    const accountId = document.getElementById('editAccountId').value;
    const account = appState.accounts.find(acc => acc.id === accountId);
    
    if (!account) return;
    
    if (account.isEdited) {
        alert('This account has already been edited!');
        hideEditModal();
        return;
    }
    
    // Update account details
    account.name = document.getElementById('editFullName').value;
    account.email = document.getElementById('editEmail').value;
    account.cash = parseFloat(document.getElementById('editCash').value);
    account.coins = parseFloat(document.getElementById('editCoins').value);
    account.isEdited = true; // Mark as edited - no more edits allowed
    
    addSecurityLog('SUCCESS', 'Account edited', 'Account: ' + account.accountNumber);
    saveToStorage();
    
    hideEditModal();
    loadAccounts();
    updateDashboardStats();
    
    alert('Account updated successfully. No further edits will be allowed.');
}

function deleteAccount(accountId) {
    const password = prompt('Enter admin password to delete this account:');
    
    if (password !== appState.adminPassword) {
        alert('Invalid password!');
        addSecurityLog('ALERT', 'Unauthorized account deletion attempt', 'Account ID: ' + accountId);
        return;
    }
    
    if (confirm('Are you sure you want to delete this account? This action cannot be undone.')) {
        const account = appState.accounts.find(acc => acc.id === accountId);
        appState.accounts = appState.accounts.filter(acc => acc.id !== accountId);
        
        addSecurityLog('SUCCESS', 'Account deleted', 'Account: ' + account.accountNumber);
        saveToStorage();
        
        loadAccounts();
        updateDashboardStats();
        
        alert('Account deleted successfully!');
    }
}

function filterAccounts() {
    loadAccounts();
}

function searchAccounts() {
    loadAccounts();
}

// Payment Functions
function showPaymentTab(tabId) {
    // Hide all payment sections
    document.querySelectorAll('.payment-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remove active class from all tabs
    document.querySelectorAll('.payment-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(tabId + 'Payment').classList.add('active');
    event.target.classList.add('active');
    
    if (tabId === 'history') {
        loadTransactions();
    }
}

function updatePaymentAccountSelects() {
    const fromAccountSelect = document.getElementById('fromAccount');
    const toIncomingAccountSelect = document.getElementById('toIncomingAccount');
    
    if (fromAccountSelect) {
        fromAccountSelect.innerHTML = '<option value="">Select Account</option>' +
            appState.accounts.map(acc => 
                `<option value="${acc.id}">${acc.type === 'global' ? 'GBN' : 'Pilgrim'} - ${acc.accountNumber} - ${acc.name}</option>`
            ).join('');
    }
    
    if (toIncomingAccountSelect) {
        toIncomingAccountSelect.innerHTML = '<option value="">Select Destination Account</option>' +
            appState.accounts.map(acc => 
                `<option value="${acc.id}">${acc.type === 'global' ? 'GBN' : 'Pilgrim'} - ${acc.accountNumber} - ${acc.name}</option>`
            ).join('');
    }
}

function handleOutgoingPayment(e) {
    e.preventDefault();
    
    const fromAccountId = document.getElementById('fromAccount').value;
    const toAccountNumber = document.getElementById('toAccount').value;
    const destinationNetwork = document.getElementById('destinationNetwork').value;
    const amount = parseFloat(document.getElementById('paymentAmount').value);
    const paymentType = document.getElementById('paymentType').value;
    const recipientName = document.getElementById('recipientName').value;
    const description = document.getElementById('paymentDescription').value || 'Payment';
    
    // Validate
    if (!fromAccountId || !toAccountNumber || !amount || !recipientName) {
        alert('Please fill all required fields');
        return;
    }
    
    const fromAccount = appState.accounts.find(acc => acc.id === fromAccountId);
    if (!fromAccount) {
        alert('Source account not found');
        return;
    }
    
    // Check balance
    const balanceToUse = paymentType === 'cash' ? fromAccount.cash : fromAccount.coins;
    if (balanceToUse < amount) {
        alert('Insufficient ' + paymentType + ' balance');
        return;
    }
    
    // Network Validation Robot - Check if destination is registered
    const isDestinationRegistered = appState.accounts.some(acc => acc.accountNumber === toAccountNumber);
    
    if (destinationNetwork !== 'external' && !isDestinationRegistered) {
        alert('Network Validation Robot: Destination account not registered in the system');
        addSecurityLog('WARNING', 'Payment to unregistered account attempted', 'Destination: ' + toAccountNumber);
        return;
    }
    
    // Process payment
    if (paymentType === 'cash') {
        fromAccount.cash -= amount;
    } else {
        fromAccount.coins -= amount;
    }
    fromAccount.debit += amount;
    
    // Create transaction record
    const transaction = {
        id: generateId(),
        type: 'debit',
        fromAccount: fromAccount.accountNumber,
        toAccount: toAccountNumber,
        amount: amount,
        paymentType: paymentType,
        description: description + ' to ' + recipientName,
        network: destinationNetwork,
        date: new Date().toISOString(),
        recipient: recipientName,
        registered: isDestinationRegistered
    };
    
    appState.transactions.push(transaction);
    addSecurityLog('SUCCESS', 'Payment processed', `₦${amount} sent to ${toAccountNumber}`);
    saveToStorage();
    
    // Reset form
    document.getElementById('outgoingPaymentForm').reset();
    
    // Update displays
    updateDashboardStats();
    loadAccounts();
    
    alert(`Payment of ${formatCurrency(amount)} successfully sent to ${recipientName} (${toAccountNumber})`);
}

function processIncomingPayment() {
    const sourceAccount = document.getElementById('sourceAccount').value;
    const sourceNetwork = document.getElementById('sourceNetwork').value;
    const senderName = document.getElementById('senderName').value;
    const senderNetwork = document.getElementById('senderNetwork').value;
    const amount = parseFloat(document.getElementById('incomingAmount').value);
    const paymentType = document.getElementById('incomingType').value;
    const toAccountId = document.getElementById('toIncomingAccount').value;
    const sourceUrl = document.getElementById('sourceUrl').value;
    
    if (!toAccountId || !amount) {
        alert('Please fill all required fields');
        return;
    }
    
    const toAccount = appState.accounts.find(acc => acc.id === toAccountId);
    if (!toAccount) {
        alert('Destination account not found');
        return;
    }
    
    // Process incoming payment - Always accept
    if (paymentType === 'cash') {
        toAccount.cash += amount;
    } else {
        toAccount.coins += amount;
    }
    toAccount.credit += amount;
    
    // Create transaction record
    const transaction = {
        id: generateId(),
        type: 'credit',
        fromAccount: sourceAccount || 'External Source',
        toAccount: toAccount.accountNumber,
        amount: amount,
        paymentType: paymentType,
        description: 'Payment from ' + (senderName || 'Unknown'),
        network: sourceNetwork,
        date: new Date().toISOString(),
        sender: senderName,
        senderNetwork: senderNetwork,
        sourceUrl: sourceUrl
    };
    
    appState.transactions.push(transaction);
    addSecurityLog('SUCCESS', 'Incoming payment accepted', `₦${amount} received from ${senderName || 'External'}`);
    saveToStorage();
    
    // Reset form
    document.getElementById('sourceAccount').value = '';
    document.getElementById('senderName').value = '';
    document.getElementById('incomingAmount').value = '';
    document.getElementById('sourceUrl').value = '';
    
    // Update displays
    updateDashboardStats();
    loadAccounts();
    
    alert(`Payment of ${formatCurrency(amount)} received successfully!`);
}

function loadTransactions() {
    const transactionsList = document.getElementById('transactionsList');
    if (!transactionsList) return;
    
    const filter = document.getElementById('historyFilter');
    let filteredTransactions = [...appState.transactions];
    
    // Apply filter
    if (filter && filter.value !== 'all') {
        filteredTransactions = filteredTransactions.filter(t => t.type === filter.value);
    }
    
    // Sort by date (newest first)
    filteredTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    if (filteredTransactions.length === 0) {
        transactionsList.innerHTML = '<p class="no-transactions">No transactions found</p>';
        return;
    }
    
    transactionsList.innerHTML = filteredTransactions.map(t => `
        <div class="transaction-item ${t.type}">
            <div class="transaction-details">
                <div>
                    <strong>${t.type === 'credit' ? 'Received' : 'Sent'}</strong>
                    <p>${t.description}</p>
                    <small>${new Date(t.date).toLocaleString()}</small>
                </div>
                ${t.network ? `<p><strong>Network:</strong> ${t.network}</p>` : ''}
                ${t.registered !== undefined ? `<p><strong>Registered:</strong> ${t.registered ? 'Yes' : 'No'}</p>` : ''}
            </div>
            <div class="transaction-amount">
                ${t.type === 'credit' ? '+' : '-'}${formatCurrency(t.amount)}
            </div>
        </div>
    `).join('');
}

function filterTransactions() {
    loadTransactions();
}

// Bank Linking Functions
function handleBankLink(e) {
    e.preventDefault();
    
    const newLink = {
        id: generateId(),
        bankName: document.getElementById('bankName').value,
        bankUrl: document.getElementById('bankUrl').value,
        apiEndpoint: document.getElementById('apiEndpoint').value,
        connectionType: document.getElementById('connectionTypeLink').value,
        apiKey: document.getElementById('apiKey').value,
        status: 'pending',
        createdDate: new Date().toISOString()
    };
    
    appState.linkedBanks.push(newLink);
    addSecurityLog('SUCCESS', 'New bank link added', 'Bank: ' + newLink.bankName);
    saveToStorage();
    
    // Reset form
    document.getElementById('bankLinkForm').reset();
    
    loadLinkedBanks();
    alert('Bank link added successfully! Status: Pending approval');
}

function loadLinkedBanks() {
    const linkedBanksList = document.getElementById('linkedBanksList');
    if (!linkedBanksList) return;
    
    if (appState.linkedBanks.length === 0) {
        linkedBanksList.innerHTML = '<p class="no-links">No banks linked yet</p>';
        return;
    }
    
    linkedBanksList.innerHTML = appState.linkedBanks.map(link => `
        <div class="bank-item">
            <div>
                <strong>${link.bankName}</strong>
                <p>${link.bankUrl}</p>
                <small>Type: ${link.connectionType === 'global' ? 'Global Bank' : 'Pilgrim'}</small>
            </div>
            <div>
                <span class="bank-status ${link.status === 'connected' ? 'connected' : 'pending'}">${link.status}</span>
                ${link.status === 'pending' ? 
                    `<button onclick="approveLink('${link.id}')" class="primary-btn" style="margin-left: 10px; padding: 5px 10px;">Approve</button>` :
                    ''
                }
                <button onclick="removeLink('${link.id}')" class="delete-btn" style="margin-left: 10px; padding: 5px 10px;">Remove</button>
            </div>
        </div>
    `).join('');
}

function approveLink(linkId) {
    const password = prompt('Enter admin password to approve this link:');
    
    if (password !== appState.adminPassword) {
        alert('Invalid password!');
        return;
    }
    
    const link = appState.linkedBanks.find(l => l.id === linkId);
    if (link) {
        link.status = 'connected';
        addSecurityLog('SUCCESS', 'Bank link approved', 'Bank: ' + link.bankName);
        saveToStorage();
        loadLinkedBanks();
    }
}

function removeLink(linkId) {
    const password = prompt('Enter admin password to remove this link:');
    
    if (password !== appState.adminPassword) {
        alert('Invalid password!');
        return;
    }
    
    const link = appState.linkedBanks.find(l => l.id === linkId);
    appState.linkedBanks = appState.linkedBanks.filter(l => l.id !== linkId);
    
    addSecurityLog('SUCCESS', 'Bank link removed', 'Bank: ' + link.bankName);
    saveToStorage();
    loadLinkedBanks();
}

// Security Functions
function addSecurityLog(type, message, details) {
    const log = {
        id: generateId(),
        type: type,
        message: message,
        details: details,
        timestamp: new Date().toISOString()
    };
    
    appState.securityLogs.push(log);
    
    // Keep only last 100 logs
    if (appState.securityLogs.length > 100) {
        appState.securityLogs = appState.securityLogs.slice(-100);
    }
    
    saveToStorage();
}

function updateSecurityLogs() {
    const securityLogs = document.getElementById('securityLogs');
    if (!securityLogs) return;
    
    if (appState.securityLogs.length === 0) {
        securityLogs.innerHTML = '<p>No security events recorded</p>';
        return;
    }
    
    // Show last 20 logs, newest first
    const recentLogs = appState.securityLogs.slice(-20).reverse();
    
    securityLogs.innerHTML = recentLogs.map(log => `
        <div class="log-item">
            <div>
                <span style="font-weight: bold; color: ${getLogColor(log.type)};">[${log.type}]</span>
                <span>${log.message}</span>
            </div>
            <small>${new Date(log.timestamp).toLocaleString()}</small>
        </div>
    `).join('');
}

function getLogColor(type) {
    switch(type) {
        case 'ALERT': return '#e74c3c';
        case 'WARNING': return '#f39c12';
        case 'SUCCESS': return '#27ae60';
        default: return '#3498db';
    }
}

function showDeleteAllModal() {
    document.getElementById('deleteModal').style.display = 'flex';
}

function hideDeleteModal() {
    document.getElementById('deleteModal').style.display = 'none';
    document.getElementById('deleteConfirmForm').reset();
}

function handleDeleteConfirm(e) {
    e.preventDefault();
    
    const password = document.getElementById('deletePassword').value;
    
    if (password !== appState.adminPassword) {
        alert('Invalid admin password!');
        addSecurityLog('ALERT', 'Unauthorized deletion attempt', 'Invalid password provided');
        return;
    }
    
    if (confirm('WARNING: This will permanently delete ALL data including accounts, transactions, and logs. This action cannot be undone! Are you absolutely sure?')) {
        // Clear all data
        appState.accounts = [];
        appState.transactions = [];
        appState.linkedBanks = [];
        appState.securityLogs = [];
        appState.connections = [];
        
        addSecurityLog('SUCCESS', 'All data deleted by admin', 'System reset complete');
        saveToStorage();
        
        hideDeleteModal();
        
        // Reload page
        location.reload();
    }
}

function exportData() {
    const password = prompt('Enter admin password to export data:');
    
    if (password !== appState.adminPassword) {
        alert('Invalid password!');
        return;
    }
    
    const data = {
        accounts: appState.accounts,
        transactions: appState.transactions,
        linkedBanks: appState.linkedBanks,
        securityLogs: appState.securityLogs,
        exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = 'banking_database_export_' + new Date().toISOString().split('T')[0] + '.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    addSecurityLog('SUCCESS', 'Database exported', 'Export completed by admin');
    alert('Database exported successfully!');
}

// Utility Functions
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

function formatCurrency(amount) {
    return '₦' + amount.toLocaleString('en-NG', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        appState.isLoggedIn = false;
        appState.currentUser = null;
        addSecurityLog('INFO', 'Admin logged out', 'User: ' + appState.currentUser);
        saveToStorage();
        window.location.href = 'index.html';
    }
}

// Local Storage Functions
function saveToStorage() {
    localStorage.setItem('bankingApp', JSON.stringify(appState));
}

function loadFromStorage() {
    const stored = localStorage.getItem('bankingApp');
    if (stored) {
        const parsed = JSON.parse(stored);
        appState = { ...appState, ...parsed };
    }
}