// Pilgrim Crypto Wallet
// Adegan Global Enterprise

let currentWallet = null;

// Supported currencies with their symbols and exchange rates to NGN
const currencies = {
    USD: { symbol: '$', name: 'US Dollar', rate: 1250, icon: '🇺🇸' },
    GBP: { symbol: '£', name: 'British Pound', rate: 1580, icon: '🇬🇧' },
    EUR: { symbol: '€', name: 'Euro', rate: 1350, icon: '🇪🇺' },
    NGN: { symbol: '₦', name: 'Nigerian Naira', rate: 1, icon: '🇳🇬' },
    CNY: { symbol: '¥', name: 'Chinese Yuan', rate: 175, icon: '🇨🇳' },
    RUB: { symbol: '₽', name: 'Russian Ruble', rate: 15, icon: '🇷🇺' },
    AUD: { symbol: 'A$', name: 'Australian Dollar', rate: 820, icon: '🇦🇺' },
    GHS: { symbol: 'GH₵', name: 'Ghana Cedi', rate: 105, icon: '🇬🇭' },
    ZAR: { symbol: 'R', name: 'South African Rand', rate: 68, icon: '🇿🇦' },
    UAH: { symbol: '₴', name: 'Ukrainian Hryvnia', rate: 35, icon: '🇺🇦' },
    JPY: { symbol: '¥', name: 'Japanese Yen', rate: 8.5, icon: '🇯🇵' },
    BRL: { symbol: 'R$', name: 'Brazilian Real', rate: 250, icon: '🇧🇷' },
    ARS: { symbol: '$', name: 'Argentine Peso', rate: 1.5, icon: '🇦🇷' },
    CAD: { symbol: 'C$', name: 'Canadian Dollar', rate: 920, icon: '🇨🇦' },
    BTC: { symbol: '₿', name: 'Bitcoin', rate: 45000000, icon: '₿' },
    ETH: { symbol: 'Ξ', name: 'Ethereum', rate: 2800000, icon: 'Ξ' }
};

document.addEventListener('DOMContentLoaded', function() {
    initializeWallet();
});

function initializeWallet() {
    detectLoginSecurityInfo();
    setupEventListeners();
    createDefaultWallets();
}

function detectLoginSecurityInfo() {
    const locations = ['Lagos, Nigeria', 'Abuja, Nigeria', 'Ibadan, Nigeria'];
    document.getElementById('loginLocation').textContent = locations[Math.floor(Math.random() * locations.length)];
    document.getElementById('loginIP').textContent = '192.168.1.' + Math.floor(Math.random() * 255);
}

function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('walletLoginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleWalletLogin);
    }
    
    // Send form
    const sendForm = document.getElementById('sendForm');
    if (sendForm) {
        sendForm.addEventListener('submit', handleSend);
    }
    
    // Exchange form
    const exchangeForm = document.getElementById('exchangeForm');
    if (exchangeForm) {
        exchangeForm.addEventListener('submit', handleExchange);
    }
}

function createDefaultWallets() {
    const db = window.database.get();
    
    // Create wallets for all currencies if they don't exist
    Object.keys(currencies).forEach(currencyCode => {
        const existingWallet = db.wallets.find(w => w.currency === currencyCode && w.owner === 'demo');
        if (!existingWallet) {
            window.database.wallets.create({
                currency: currencyCode,
                owner: 'demo',
                customerName: 'Demo User',
                email: 'demo@pilgrim.com',
                balance: 0
            });
        }
    });
}

function handleWalletLogin(e) {
    e.preventDefault();
    
    const walletOrEmail = document.getElementById('loginWallet').value;
    const password = document.getElementById('loginPassword').value;
    
    const db = window.database.get();
    
    // Find wallet by address or email
    let wallet = db.wallets.find(w => w.walletAddress === walletOrEmail);
    if (!wallet) {
        wallet = db.wallets.find(w => w.email === walletOrEmail);
    }
    
    if (!wallet) {
        utils.alert.error('Wallet not found. Please check your wallet address or email.');
        return;
    }
    
    // Simple password check (demo only)
    if (password !== 'demo123') {
        utils.alert.error('Invalid password');
        return;
    }
    
    // Login successful
    currentWallet = wallet;
    showDashboard();
}

function showDashboard() {
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('dashboardSection').style.display = 'block';
    
    // Update wallet info
    document.getElementById('walletOwner').textContent = currentWallet.customerName;
    
    // Start date/time update
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    // Load wallets and transactions
    loadWallets();
    loadTransactionHistory();
}

function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const dateTimeElement = document.getElementById('currentDateTime');
    if (dateTimeElement) {
        dateTimeElement.textContent = now.toLocaleDateString('en-NG', options);
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show selected section
    document.getElementById(sectionId + 'Section').style.display = 'block';
    
    // Populate dropdowns when showing send/receive/exchange
    if (sectionId === 'send' || sectionId === 'receive' || sectionId === 'exchange') {
        populateWalletDropdowns();
    }
}

function loadWallets() {
    const db = window.database.get();
    const wallets = db.wallets.filter(w => w.owner === 'demo');
    
    const walletsDiv = document.getElementById('walletsList');
    if (!walletsDiv) return;
    
    if (wallets.length === 0) {
        walletsDiv.innerHTML = '<p class="no-data">No wallets found</p>';
        return;
    }
    
    // Calculate total balance in NGN
    let totalNGN = 0;
    
    walletsDiv.innerHTML = wallets.map(wallet => {
        const currency = currencies[wallet.currency];
        const ngnValue = wallet.balance * currency.rate;
        totalNGN += ngnValue;
        
        return `
            <div class="wallet-item">
                <div class="wallet-icon">
                    <span class="currency-icon">${currency.icon}</span>
                </div>
                <div class="wallet-info">
                    <div class="wallet-name">${currency.name}</div>
                    <div class="wallet-address">${wallet.walletAddress.substring(0, 16)}...</div>
                </div>
                <div class="wallet-balance">
                    <div class="balance-amount">${currency.symbol}${wallet.balance.toLocaleString()}</div>
                    <div class="balance-ngn">≈ ${utils.format.currencyNGN(ngnValue)}</div>
                </div>
                <div class="wallet-actions">
                    <button class="action-icon" onclick="showSection('send')">💸</button>
                    <button class="action-icon" onclick="showSection('receive')">📥</button>
                </div>
            </div>
        `;
    }).join('');
    
    // Update total balance
    document.getElementById('totalBalance').textContent = utils.format.currencyNGN(totalNGN);
}

function populateWalletDropdowns() {
    const db = window.database.get();
    const wallets = db.wallets.filter(w => w.owner === 'demo');
    
    // Send dropdown
    const sendFromWallet = document.getElementById('sendFromWallet');
    if (sendFromWallet) {
        sendFromWallet.innerHTML = '<option value="">Select Wallet</option>' +
            wallets.map(w => {
                const currency = currencies[w.currency];
                return `<option value="${w.id}">${currency.icon} ${currency.name} - ${currency.symbol}${w.balance}</option>`;
            }).join('');
    }
    
    // Receive dropdown
    const receiveWallet = document.getElementById('receiveWallet');
    if (receiveWallet) {
        receiveWallet.innerHTML = '<option value="">Select Wallet</option>' +
            wallets.map(w => {
                const currency = currencies[w.currency];
                return `<option value="${w.id}">${currency.icon} ${currency.name}</option>`;
            }).join('');
    }
    
    // Exchange dropdowns
    const exchangeFromWallet = document.getElementById('exchangeFromWallet');
    const exchangeToWallet = document.getElementById('exchangeToWallet');
    
    if (exchangeFromWallet) {
        exchangeFromWallet.innerHTML = '<option value="">Select Wallet</option>' +
            wallets.map(w => {
                const currency = currencies[w.currency];
                return `<option value="${w.id}">${currency.icon} ${currency.name}</option>`;
            }).join('');
    }
    
    if (exchangeToWallet) {
        exchangeToWallet.innerHTML = '<option value="">Select Wallet</option>' +
            wallets.map(w => {
                const currency = currencies[w.currency];
                return `<option value="${w.id}">${currency.icon} ${currency.name}</option>`;
            }).join('');
    }
}

function handleSend(e) {
    e.preventDefault();
    
    const fromWalletId = document.getElementById('sendFromWallet').value;
    const toAddress = document.getElementById('sendToAddress').value;
    const amount = parseFloat(document.getElementById('sendAmount').value);
    const description = document.getElementById('sendDescription').value || 'Send';
    
    if (!fromWalletId) {
        utils.alert.error('Please select a wallet');
        return;
    }
    
    const fromWallet = window.database.wallets.get(fromWalletId);
    if (!fromWallet) {
        utils.alert.error('Wallet not found');
        return;
    }
    
    if (fromWallet.balance < amount) {
        utils.alert.error('Insufficient balance');
        return;
    }
    
    // Deduct from sender
    window.database.wallets.updateBalance(fromWalletId, fromWallet.balance - amount);
    
    // Create transaction record
    window.database.transactions.create({
        accountNumber: fromWallet.walletAddress,
        toAccount: toAddress,
        amount: amount,
        type: 'debit',
        description: `${description} to ${toAddress.substring(0, 16)}...`,
        status: 'completed'
    });
    
    const currency = currencies[fromWallet.currency];
    utils.alert.success(`Sent ${currency.symbol}${amount.toLocaleString()} to ${toAddress.substring(0, 16)}...`);
    
    document.getElementById('sendForm').reset();
    loadWallets();
    loadTransactionHistory();
}

function displayReceiveInfo() {
    const walletId = document.getElementById('receiveWallet').value;
    const receiveInfo = document.getElementById('receiveInfo');
    
    if (!walletId) {
        receiveInfo.style.display = 'none';
        return;
    }
    
    const wallet = window.database.wallets.get(walletId);
    if (!wallet) return;
    
    receiveInfo.style.display = 'block';
    
    // Display wallet address
    document.getElementById('receiveAddress').textContent = wallet.walletAddress;
    
    // Display barcode
    document.getElementById('receiveBarcode').innerHTML = `
        <div class="barcode">
            ${wallet.barcode}
        </div>
        <p class="barcode-label">Scan to send ${currencies[wallet.currency].name}</p>
    `;
}

function copyAddress() {
    const address = document.getElementById('receiveAddress').textContent;
    navigator.clipboard.writeText(address).then(() => {
        utils.alert.success('Wallet address copied to clipboard');
    });
}

function updateExchangeEstimate() {
    const fromWalletId = document.getElementById('exchangeFromWallet').value;
    const toWalletId = document.getElementById('exchangeToWallet').value;
    const amount = parseFloat(document.getElementById('exchangeAmount').value) || 0;
    
    if (!fromWalletId || !toWalletId || !amount) {
        document.getElementById('exchangeRate').textContent = '1:1';
        document.getElementById('estimatedAmount').textContent = '0.00';
        return;
    }
    
    const fromWallet = window.database.wallets.get(fromWalletId);
    const toWallet = window.database.wallets.get(toWalletId);
    
    if (!fromWallet || !toWallet) return;
    
    const fromCurrency = currencies[fromWallet.currency];
    const toCurrency = currencies[toWallet.currency];
    
    // Convert through NGN
    const ngnValue = amount * fromCurrency.rate;
    const convertedAmount = ngnValue / toCurrency.rate;
    
    const rate = fromCurrency.rate / toCurrency.rate;
    
    document.getElementById('exchangeRate').textContent = `1 ${fromCurrency.symbol} = ${rate.toFixed(6)} ${toCurrency.symbol}`;
    document.getElementById('estimatedAmount').textContent = `${toCurrency.symbol}${convertedAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}`;
}

function handleExchange(e) {
    e.preventDefault();
    
    const fromWalletId = document.getElementById('exchangeFromWallet').value;
    const toWalletId = document.getElementById('exchangeToWallet').value;
    const amount = parseFloat(document.getElementById('exchangeAmount').value);
    
    if (!fromWalletId || !toWalletId || !amount) {
        utils.alert.error('Please fill all fields');
        return;
    }
    
    const fromWallet = window.database.wallets.get(fromWalletId);
    const toWallet = window.database.wallets.get(toWalletId);
    
    if (!fromWallet || !toWallet) {
        utils.alert.error('Wallet not found');
        return;
    }
    
    if (fromWallet.balance < amount) {
        utils.alert.error('Insufficient balance in source wallet');
        return;
    }
    
    const fromCurrency = currencies[fromWallet.currency];
    const toCurrency = currencies[toWallet.currency];
    
    // Convert through NGN
    const ngnValue = amount * fromCurrency.rate;
    const convertedAmount = ngnValue / toCurrency.rate;
    
    // Update balances
    window.database.wallets.updateBalance(fromWalletId, fromWallet.balance - amount);
    window.database.wallets.updateBalance(toWalletId, toWallet.balance + convertedAmount);
    
    // Create transaction records
    window.database.transactions.create({
        accountNumber: fromWallet.walletAddress,
        toAccount: toWallet.walletAddress,
        amount: amount,
        type: 'debit',
        description: `Exchange ${fromCurrency.symbol}${amount} to ${toCurrency.symbol}${convertedAmount.toFixed(6)}`,
        status: 'completed'
    });
    
    window.database.transactions.create({
        accountNumber: toWallet.walletAddress,
        fromAccount: fromWallet.walletAddress,
        amount: convertedAmount,
        type: 'credit',
        description: `Received from exchange of ${fromCurrency.symbol}${amount}`,
        status: 'completed'
    });
    
    utils.alert.success(`Exchanged ${fromCurrency.symbol}${amount} to ${toCurrency.symbol}${convertedAmount.toFixed(6)}`);
    
    document.getElementById('exchangeForm').reset();
    loadWallets();
    loadTransactionHistory();
}

function loadTransactionHistory() {
    const db = window.database.get();
    const filter = document.getElementById('historyFilter').value;
    
    let transactions = db.transactions.filter(t => {
        // Filter by demo wallets
        const fromWallet = db.wallets.find(w => w.walletAddress === t.accountNumber);
        const toWallet = db.wallets.find(w => w.walletAddress === t.toAccount);
        return (fromWallet && fromWallet.owner === 'demo') || (toWallet && toWallet.owner === 'demo');
    });
    
    // Apply filter
    if (filter !== 'all') {
        transactions = transactions.filter(t => t.type === filter);
    }
    
    // Sort by date (newest first)
    transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const transactionsDiv = document.getElementById('transactionList');
    if (!transactionsDiv) return;
    
    if (transactions.length === 0) {
        transactionsDiv.innerHTML = '<p class="no-data">No transactions found</p>';
        return;
    }
    
    transactionsDiv.innerHTML = `
        <div class="transactions-table">
            ${transactions.map(t => `
                <div class="transaction-item ${t.type === 'credit' ? 'credit' : 'debit'}">
                    <div class="transaction-info">
                        <div class="transaction-type">
                            <strong>${t.type === 'credit' ? 'Received' : t.type === 'exchange' ? 'Exchange' : 'Sent'}</strong>
                            <small>${utils.format.dateTime(t.createdAt)}</small>
                        </div>
                        <div class="transaction-description">${t.description}</div>
                    </div>
                    <div class="transaction-amount">
                        ${t.type === 'credit' ? '+' : '-'}${utils.format.currencyNGN(t.amount)}
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        currentWallet = null;
        document.getElementById('dashboardSection').style.display = 'none';
        document.getElementById('loginSection').style.display = 'block';
        document.getElementById('walletLoginForm').reset();
    }
}