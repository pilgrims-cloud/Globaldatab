// Global Bank Nigeria Admin Dashboard
// Adegan Global Enterprise

document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
});

function initializeDashboard() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    loadDashboardStats();
    loadCustomers();
    loadAccounts();
    loadTransactions();
    loadSecurityLogs();
    
    setupEventListeners();
}

function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const dateTimeElement = document.getElementById('currentDateTime');
    if (dateTimeElement) {
        dateTimeElement.textContent = now.toLocaleDateString('en-NG', options);
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
    
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Load section-specific data
    if (sectionId === 'customers') loadCustomers();
    if (sectionId === 'accounts') loadAccounts();
    if (sectionId === 'transactions') loadTransactions();
    if (sectionId === 'kyc') loadKYC();
    if (sectionId === 'approvals') loadApprovals();
    if (sectionId === 'security') loadSecurityLogs();
}

function loadDashboardStats() {
    const db = window.database.get();
    const accounts = db.accounts;
    const transactions = db.transactions;
    
    // Total customers
    document.getElementById('totalCustomers').textContent = accounts.length;
    
    // Total balance
    const totalBalance = accounts.reduce((sum, acc) => sum + (acc.balance || 0), 0);
    document.getElementById('totalBalance').textContent = utils.format.currencyNGN(totalBalance);
    
    // Today's transactions
    const today = new Date().toDateString();
    const todayTransactions = transactions.filter(t => 
        new Date(t.createdAt).toDateString() === today
    );
    document.getElementById('todayTransactions').textContent = todayTransactions.length;
    
    // Pending KYC
    const pendingKYC = accounts.filter(acc => acc.kycStatus === 'pending').length;
    document.getElementById('pendingKYC').textContent = pendingKYC;
    
    // Load recent activities
    loadRecentActivities();
}

function loadRecentActivities() {
    const db = window.database.get();
    const recentTransactions = db.transactions
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5);
    
    const activitiesDiv = document.getElementById('recentActivities');
    if (!activitiesDiv) return;
    
    if (recentTransactions.length === 0) {
        activitiesDiv.innerHTML = '<p>No recent activities</p>';
        return;
    }
    
    activitiesDiv.innerHTML = recentTransactions.map(t => `
        <div class="activity-item">
            <div>
                <strong>${t.type === 'credit' ? 'Credit' : 'Debit'}</strong>
                <p>${t.description}</p>
            </div>
            <div class="transaction-amount ${t.type}">
                ${t.type === 'credit' ? '+' : '-'}${utils.format.currencyNGN(t.amount)}
            </div>
        </div>
    `).join('');
}

function createNewCustomer() {
    document.getElementById('customerModal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function setupEventListeners() {
    // Customer form
    const customerForm = document.getElementById('customerForm');
    if (customerForm) {
        customerForm.addEventListener('submit', handleCustomerRegistration);
    }
    
    // Transfer form
    const transferForm = document.getElementById('transferForm');
    if (transferForm) {
        transferForm.addEventListener('submit', handleTransfer);
    }
}

function handleCustomerRegistration(e) {
    e.preventDefault();
    
    const db = window.database.get();
    
    // Check if phone, NIN, or BVN already exists
    const phone = document.getElementById('customerPhone').value;
    const nin = document.getElementById('customerNIN').value;
    const bvn = document.getElementById('customerBVN').value;
    
    if (window.database.accounts.findByPhone(phone)) {
        utils.alert.error('Phone number already registered');
        return;
    }
    
    if (window.database.accounts.findByNIN(nin)) {
        utils.alert.error('NIN already registered');
        return;
    }
    
    if (window.database.accounts.findByBVN(bvn)) {
        utils.alert.error('BVN already registered');
        return;
    }
    
    // Create customer account
    const accountData = {
        name: document.getElementById('customerName').value,
        dob: document.getElementById('customerDOB').value,
        phone: phone,
        email: document.getElementById('customerEmail').value,
        nin: nin,
        bvn: bvn,
        address: document.getElementById('customerAddress').value,
        accountType: document.getElementById('accountType').value,
        documents: {
            passport: 'data:image/jpeg;base64,placeholder',
            signature: 'data:image/jpeg;base64,placeholder',
            idDocument: 'data:application/pdf;base64,placeholder',
            idType: document.getElementById('idType').value
        }
    };
    
    const account = window.database.accounts.create(accountData);
    
    // Initial deposit
    const initialDeposit = parseFloat(document.getElementById('initialDeposit').value);
    if (initialDeposit > 0) {
        window.database.transactions.create({
            accountNumber: account.accountNumber,
            amount: initialDeposit,
            type: 'credit',
            description: 'Initial deposit',
            status: 'completed'
        });
    }
    
    closeModal('customerModal');
    document.getElementById('customerForm').reset();
    
    utils.alert.success(`Customer registered successfully!\nAccount: ${account.accountNumber}\nPIN: ${account.pin}`);
    
    loadDashboardStats();
    loadCustomers();
    loadAccounts();
}

function loadCustomers() {
    const db = window.database.get();
    const customers = db.accounts;
    
    const customersDiv = document.getElementById('customersList');
    if (!customersDiv) return;
    
    if (customers.length === 0) {
        customersDiv.innerHTML = '<p class="no-data">No customers found</p>';
        return;
    }
    
    customersDiv.innerHTML = customers.map(customer => `
        <div class="customer-card">
            <div class="customer-header">
                <div class="customer-info">
                    <h3>${customer.name}</h3>
                    <p>Account: ${customer.accountNumber}</p>
                </div>
                <span class="badge ${customer.status === 'active' ? 'success' : 'warning'}">${customer.status}</span>
            </div>
            <div class="customer-details">
                <p><strong>Phone:</strong> ${customer.phone}</p>
                <p><strong>Email:</strong> ${customer.email}</p>
                <p><strong>NIN:</strong> ${customer.nin}</p>
                <p><strong>BVN:</strong> ${customer.bvn}</p>
                <p><strong>Balance:</strong> ${utils.format.currencyNGN(customer.balance || 0)}</p>
                <p><strong>KYC Status:</strong> ${customer.kycStatus || 'pending'}</p>
            </div>
            <div class="customer-actions">
                <button class="primary-btn" onclick="viewCustomer('${customer.id}')">View</button>
                <button class="warning-btn" onclick="editCustomer('${customer.id}')">Edit</button>
                <button class="success-btn" onclick="creditAccount('${customer.accountNumber}')">Credit</button>
                <button class="danger-btn" onclick="debitAccount('${customer.accountNumber}')">Debit</button>
            </div>
        </div>
    `).join('');
}

function loadAccounts() {
    const db = window.database.get();
    const accounts = db.accounts;
    
    const accountsDiv = document.getElementById('accountsList');
    if (!accountsDiv) return;
    
    // Populate from account dropdown for transfers
    const fromAccountSelect = document.getElementById('fromAccount');
    if (fromAccountSelect) {
        fromAccountSelect.innerHTML = '<option value="">Select Source Account</option>' +
            accounts.map(acc => 
                `<option value="${acc.accountNumber}">${acc.accountNumber} - ${acc.name}</option>`
            ).join('');
    }
    
    if (accounts.length === 0) {
        accountsDiv.innerHTML = '<p class="no-data">No accounts found</p>';
        return;
    }
    
    accountsDiv.innerHTML = accounts.map(account => `
        <div class="account-card">
            <div class="account-header">
                <h3>${account.name}</h3>
                <span class="badge info">${account.accountType}</span>
            </div>
            <div class="account-details">
                <p><strong>Account Number:</strong> ${account.accountNumber}</p>
                <p><strong>Serial Number:</strong> ${account.serialNumber}</p>
                <p><strong>Balance:</strong> ${utils.format.currencyNGN(account.balance || 0)}</p>
                <p><strong>Status:</strong> ${account.status}</p>
                <p><strong>KYC:</strong> ${account.kycStatus || 'pending'}</p>
                <p><strong>Registered:</strong> ${utils.format.date(account.createdAt)}</p>
            </div>
            <div class="account-actions">
                <button class="primary-btn" onclick="viewAccount('${account.id}')">Details</button>
                <button class="success-btn" onclick="creditAccount('${account.accountNumber}')">Credit</button>
                <button class="danger-btn" onclick="debitAccount('${account.accountNumber}')">Debit</button>
            </div>
        </div>
    `).join('');
}

function loadTransactions() {
    const db = window.database.get();
    const transactions = db.transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const transactionsDiv = document.getElementById('transactionsList');
    if (!transactionsDiv) return;
    
    if (transactions.length === 0) {
        transactionsDiv.innerHTML = '<p class="no-data">No transactions found</p>';
        return;
    }
    
    transactionsDiv.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Account</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${transactions.map(t => `
                    <tr>
                        <td>${utils.format.dateTime(t.createdAt)}</td>
                        <td>${t.accountNumber}</td>
                        <td><span class="badge ${t.type === 'credit' ? 'success' : 'danger'}">${t.type.toUpperCase()}</span></td>
                        <td>${t.description}</td>
                        <td>${utils.format.currencyNGN(t.amount)}</td>
                        <td><span class="badge success">${t.status}</span></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function handleTransfer(e) {
    e.preventDefault();
    
    const fromAccount = document.getElementById('fromAccount').value;
    const toAccount = document.getElementById('toAccount').value;
    const amount = parseFloat(document.getElementById('transferAmount').value);
    const transferType = document.getElementById('transferType').value;
    const recipientName = document.getElementById('recipientName').value;
    const recipientBank = document.getElementById('recipientBank').value;
    const description = document.getElementById('transferDescription').value || `Transfer to ${recipientName}`;
    
    // Check balance
    const account = window.database.accounts.get(fromAccount);
    if (!account || account.balance < amount) {
        utils.alert.error('Insufficient balance');
        return;
    }
    
    // Debit source account
    window.database.transactions.create({
        accountNumber: fromAccount,
        toAccount: toAccount,
        amount: amount,
        type: 'debit',
        description: `${transferType.toUpperCase()} - ${description}`,
        transferType: transferType,
        recipientName: recipientName,
        recipientBank: recipientBank,
        status: 'completed'
    });
    
    utils.alert.success(`Transfer of ${utils.format.currencyNGN(amount)} processed successfully!`);
    
    document.getElementById('transferForm').reset();
    loadDashboardStats();
    loadTransactions();
    loadAccounts();
}

function creditAccount(accountNumber) {
    const amount = prompt('Enter amount to credit:');
    if (!amount || isNaN(amount)) return;
    
    const amountValue = parseFloat(amount);
    const description = prompt('Enter description:', 'Manual credit') || 'Manual credit';
    
    window.database.transactions.create({
        accountNumber: accountNumber,
        amount: amountValue,
        type: 'credit',
        description: description,
        status: 'completed'
    });
    
    utils.alert.success(`Account credited with ${utils.format.currencyNGN(amountValue)}`);
    
    loadDashboardStats();
    loadAccounts();
    loadTransactions();
}

function debitAccount(accountNumber) {
    const amount = prompt('Enter amount to debit:');
    if (!amount || isNaN(amount)) return;
    
    const amountValue = parseFloat(amount);
    const account = window.database.accounts.get(accountNumber);
    
    if (!account || account.balance < amountValue) {
        utils.alert.error('Insufficient balance');
        return;
    }
    
    const description = prompt('Enter description:', 'Manual debit') || 'Manual debit';
    
    window.database.transactions.create({
        accountNumber: accountNumber,
        amount: amountValue,
        type: 'debit',
        description: description,
        status: 'completed'
    });
    
    utils.alert.success(`Account debited with ${utils.format.currencyNGN(amountValue)}`);
    
    loadDashboardStats();
    loadAccounts();
    loadTransactions();
}

function loadKYC() {
    const db = window.database.get();
    const pendingKYC = db.accounts.filter(acc => acc.kycStatus === 'pending');
    
    const kycDiv = document.getElementById('kycList');
    if (!kycDiv) return;
    
    if (pendingKYC.length === 0) {
        kycDiv.innerHTML = '<p class="no-data">No pending KYC verifications</p>';
        return;
    }
    
    kycDiv.innerHTML = pendingKYC.map(customer => `
        <div class="kyc-card">
            <div class="kyc-header">
                <h3>${customer.name}</h3>
                <span class="badge warning">Pending</span>
            </div>
            <div class="kyc-details">
                <p><strong>Account:</strong> ${customer.accountNumber}</p>
                <p><strong>Phone:</strong> ${customer.phone}</p>
                <p><strong>Email:</strong> ${customer.email}</p>
                <p><strong>NIN:</strong> ${customer.nin}</p>
                <p><strong>BVN:</strong> ${customer.bvn}</p>
            </div>
            <div class="kyc-actions">
                <button class="primary-btn" onclick="verifyKYC('${customer.id}')">Verify</button>
                <button class="danger-btn" onclick="rejectKYC('${customer.id}')">Reject</button>
            </div>
        </div>
    `).join('');
}

function verifyKYC(accountId) {
    const account = window.database.accounts.getById(accountId);
    if (account) {
        window.database.accounts.update(accountId, {
            kycStatus: 'verified',
            status: 'active'
        });
        utils.alert.success('KYC verified successfully');
        loadKYC();
        loadDashboardStats();
    }
}

function rejectKYC(accountId) {
    const reason = prompt('Enter reason for rejection:');
    if (!reason) return;
    
    window.database.accounts.update(accountId, {
        kycStatus: 'rejected',
        status: 'suspended'
    });
    utils.alert.success('KYC rejected');
    loadKYC();
    loadDashboardStats();
}

function loadApprovals() {
    // For demo - in real system this would show pending registrations
    const db = window.database.get();
    const pendingAccounts = db.accounts.filter(acc => acc.status === 'pending');
    
    const approvalsDiv = document.getElementById('approvalsList');
    if (!approvalsDiv) return;
    
    if (pendingAccounts.length === 0) {
        approvalsDiv.innerHTML = '<p class="no-data">No pending approvals</p>';
        return;
    }
    
    approvalsDiv.innerHTML = pendingAccounts.map(account => `
        <div class="approval-card">
            <h3>${account.name}</h3>
            <p>Account: ${account.accountNumber}</p>
            <p>Type: ${account.accountType}</p>
            <div class="approval-actions">
                <button class="success-btn" onclick="approveAccount('${account.id}')">Approve</button>
                <button class="danger-btn" onclick="rejectAccount('${account.id}')">Reject</button>
            </div>
        </div>
    `).join('');
}

function approveAccount(accountId) {
    window.database.accounts.update(accountId, { status: 'active' });
    utils.alert.success('Account approved');
    loadApprovals();
    loadDashboardStats();
}

function rejectAccount(accountId) {
    window.database.accounts.update(accountId, { status: 'rejected' });
    utils.alert.success('Account rejected');
    loadApprovals();
    loadDashboardStats();
}

function loadSecurityLogs() {
    const logs = window.database.security.getLogs().slice(0, 20);
    
    const logsDiv = document.getElementById('securityLogs');
    if (!logsDiv) return;
    
    if (logs.length === 0) {
        logsDiv.innerHTML = '<p>No security logs</p>';
        return;
    }
    
    logsDiv.innerHTML = logs.map(log => `
        <div class="log-item">
            <div>
                <span class="badge ${log.type === 'ALERT' ? 'danger' : 'info'}">${log.type}</span>
                <span>${log.message}</span>
            </div>
            <small>${utils.format.dateTime(log.timestamp)}</small>
        </div>
    `).join('');
}

function searchCustomers() {
    // Implement search functionality
    loadCustomers();
}

function filterCustomers() {
    // Implement filter functionality
    loadCustomers();
}

function filterTransactions() {
    // Implement transaction filtering
    loadTransactions();
}

function viewCustomer(customerId) {
    utils.alert.info('Customer details view - Coming soon');
}

function editCustomer(customerId) {
    utils.alert.info('Customer edit - Coming soon');
}

function viewAccount(accountId) {
    utils.alert.info('Account details view - Coming soon');
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        window.location.href = '../index.html';
    }
}