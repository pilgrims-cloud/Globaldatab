// Pilgrim Coin & Cash Admin Dashboard
// Adegan Global Enterprise

let miningInterval = null;

document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    startMiningSimulation();
});

function initializeDashboard() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    loadDashboardStats();
    loadAccounts();
    loadMining();
    loadWallets();
    loadTransactions();
    
    setupEventListeners();
}

function updateDateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    };
    const dateTimeElement = document.getElementById('currentDateTime');
    if (dateTimeElement) {
        dateTimeElement.textContent = now.toLocaleDateString('en-NG', options);
    }
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
    
    // Update nav buttons
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event.target.classList.add('active');
    
    // Load section-specific data
    if (sectionId === 'accounts') loadAccounts();
    if (sectionId === 'mining') loadMining();
    if (sectionId === 'wallets') loadWallets();
    if (sectionId === 'exchange') loadExchange();
    if (sectionId === 'transactions') loadTransactions();
}

function loadDashboardStats() {
    const db = window.database.get();
    const wallets = db.wallets;
    const mining = db.mining;
    
    // Total wallets
    document.getElementById('totalWallets').textContent = wallets.length;
    
    // Total coins
    const totalCoins = mining.reduce((sum, m) => sum + m.totalMined, 0);
    document.getElementById('totalCoins').textContent = totalCoins.toFixed(8);
    
    // Total cash (coins converted to cash at 0.5 rate)
    const totalCash = totalCoins * 0.5;
    document.getElementById('totalCash').textContent = utils.format.currencyNGN(totalCash);
}

function setupEventListeners() {
    // Create account form
    const createAccountForm = document.getElementById('createAccountForm');
    if (createAccountForm) {
        createAccountForm.addEventListener('submit', handleCreateAccount);
    }
    
    // Exchange form
    const exchangeForm = document.getElementById('exchangeForm');
    if (exchangeForm) {
        exchangeForm.addEventListener('submit', handleExchange);
    }
    
    // Exchange amount change
    const exchangeAmount = document.getElementById('exchangeAmount');
    if (exchangeAmount) {
        exchangeAmount.addEventListener('input', updateExchangeEstimate);
    }
    
    // Exchange type change
    const exchangeType = document.getElementById('exchangeType');
    if (exchangeType) {
        exchangeType.addEventListener('change', updateExchangeEstimate);
    }
}

function createNewAccount() {
    document.getElementById('accountModal').style.display = 'flex';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

function handleCreateAccount(e) {
    e.preventDefault();
    
    const customerName = document.getElementById('customerName').value;
    const email = document.getElementById('customerEmail').value;
    const phone = document.getElementById('customerPhone').value;
    const initialCoins = parseFloat(document.getElementById('initialCoins').value) || 0;
    const password = document.getElementById('loginPassword').value;
    const accountType = document.getElementById('accountType').value;
    
    // Create mining account
    const miningData = {
        customerName: customerName,
        email: email,
        phone: phone,
        accountType: accountType,
        password: password,
        balance: initialCoins
    };
    
    const miningAccount = window.database.mining.create(miningData);
    
    // Create wallet
    const walletData = {
        miningId: miningAccount.id,
        customerName: customerName,
        email: email,
        currency: 'PILGRIM',
        balance: initialCoins
    };
    
    const wallet = window.database.wallets.create(walletData);
    
    closeModal('accountModal');
    document.getElementById('createAccountForm').reset();
    
    utils.alert.success(`Mining account created successfully!\nWallet Address: ${wallet.walletAddress}\n\nCustomer can login with:\nEmail: ${email}\nPassword: ${password}`);
    
    loadDashboardStats();
    loadAccounts();
    loadMining();
    loadWallets();
}

function loadAccounts() {
    const db = window.database.get();
    const miningAccounts = db.mining;
    
    const accountsDiv = document.getElementById('accountsList');
    if (!accountsDiv) return;
    
    if (miningAccounts.length === 0) {
        accountsDiv.innerHTML = '<p class="no-data">No accounts found</p>';
        return;
    }
    
    accountsDiv.innerHTML = miningAccounts.map(account => `
        <div class="account-card">
            <div class="account-header">
                <h3>${account.customerName}</h3>
                <span class="badge info">${account.accountType}</span>
            </div>
            <div class="account-details">
                <p><strong>Email:</strong> ${account.email}</p>
                <p><strong>Phone:</strong> ${account.phone}</p>
                <p><strong>Mining Balance:</strong> ${account.totalMined.toFixed(8)} PIL</p>
                <p><strong>Wallet Balance:</strong> ${account.balance.toFixed(8)} PIL</p>
                <p><strong>Status:</strong> ${account.status}</p>
            </div>
            <div class="account-actions">
                <button class="primary-btn" onclick="viewAccount('${account.id}')">View</button>
                <button class="success-btn" onclick="creditAccount('${account.id}')">Credit</button>
            </div>
        </div>
    `).join('');
}

function loadMining() {
    const db = window.database.get();
    const miningAccounts = db.mining;
    
    const miningDiv = document.getElementById('miningList');
    if (!miningDiv) return;
    
    if (miningAccounts.length === 0) {
        miningDiv.innerHTML = '<p class="no-data">No mining operations</p>';
        return;
    }
    
    miningDiv.innerHTML = miningAccounts.map(account => `
        <div class="mining-card">
            <div class="mining-header">
                <h3>${account.customerName}</h3>
                <span class="badge success">Mining</span>
            </div>
            <div class="mining-stats">
                <div class="stat">
                    <label>Total Mined:</label>
                    <span class="value">${account.totalMined.toFixed(8)} PIL</span>
                </div>
                <div class="stat">
                    <label>Current Balance:</label>
                    <span class="value">${account.balance.toFixed(8)} PIL</span>
                </div>
                <div class="stat">
                    <label>Mining Rate:</label>
                    <span class="value">0.000000001 bits/sec</span>
                </div>
                <div class="stat">
                    <label>Cash Value:</label>
                    <span class="value">${utils.format.currencyNGN(account.balance * 0.5)}</span>
                </div>
            </div>
            <div class="mining-progress">
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${Math.min((account.totalMined % 1) * 100, 100)}%"></div>
                </div>
                <small>Progress to next Pilgrim: ${(account.totalMined % 1).toFixed(8)} / 1.00000000</small>
            </div>
        </div>
    `).join('');
}

function loadWallets() {
    const db = window.database.get();
    const wallets = db.wallets;
    
    const walletsDiv = document.getElementById('walletsList');
    if (!walletsDiv) return;
    
    // Populate exchange wallet dropdown
    const exchangeWallet = document.getElementById('exchangeWallet');
    if (exchangeWallet) {
        exchangeWallet.innerHTML = '<option value="">Select Wallet</option>' +
            wallets.map(w => 
                `<option value="${w.id}">${w.customerName} - ${w.balance.toFixed(8)} ${w.currency}</option>`
            ).join('');
    }
    
    if (wallets.length === 0) {
        walletsDiv.innerHTML = '<p class="no-data">No wallets found</p>';
        return;
    }
    
    walletsDiv.innerHTML = wallets.map(wallet => `
        <div class="wallet-card">
            <div class="wallet-header">
                <h3>${wallet.customerName}</h3>
                <span class="badge info">${wallet.currency}</span>
            </div>
            <div class="wallet-details">
                <p><strong>Wallet Address:</strong></p>
                <code class="wallet-address">${wallet.walletAddress}</code>
                <p><strong>Barcode:</strong> ${wallet.barcode}</p>
                <p><strong>Balance:</strong> ${wallet.balance.toFixed(8)} ${wallet.currency}</p>
                <p><strong>Cash Value:</strong> ${utils.format.currencyNGN(wallet.balance * 0.5)}</p>
            </div>
        </div>
    `).join('');
}

function loadExchange() {
    const db = window.database.get();
    const transactions = db.transactions.filter(t => t.type === 'exchange');
    
    const exchangeHistoryDiv = document.getElementById('exchangeHistory');
    if (!exchangeHistoryDiv) return;
    
    if (transactions.length === 0) {
        exchangeHistoryDiv.innerHTML = '<p class="no-data">No exchanges yet</p>';
        return;
    }
    
    exchangeHistoryDiv.innerHTML = `
        <div class="exchange-list">
            ${transactions.slice(0, 10).map(t => `
                <div class="exchange-item">
                    <div class="exchange-info">
                        <strong>${t.exchangeType === 'coin-to-cash' ? 'Coins → Cash' : 'Cash → Coins'}</strong>
                        <small>${utils.format.dateTime(t.createdAt)}</small>
                    </div>
                    <div class="exchange-amount">
                        ${utils.format.currencyNGN(t.amount)}
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

function updateExchangeEstimate() {
    const amount = parseFloat(document.getElementById('exchangeAmount').value) || 0;
    const exchangeType = document.getElementById('exchangeType').value;
    const estimatedElement = document.getElementById('estimatedAmount');
    
    let estimated = 0;
    if (exchangeType === 'coin-to-cash') {
        estimated = amount * 0.5;
    } else {
        estimated = amount / 0.5;
    }
    
    estimatedElement.textContent = exchangeType === 'coin-to-cash' 
        ? utils.format.currencyNGN(estimated)
        : estimated.toFixed(8) + ' PIL';
}

function handleExchange(e) {
    e.preventDefault();
    
    const walletId = document.getElementById('exchangeWallet').value;
    const exchangeType = document.getElementById('exchangeType').value;
    const amount = parseFloat(document.getElementById('exchangeAmount').value);
    
    if (!walletId) {
        utils.alert.error('Please select a wallet');
        return;
    }
    
    const wallet = window.database.wallets.get(walletId);
    if (!wallet) {
        utils.alert.error('Wallet not found');
        return;
    }
    
    if (exchangeType === 'coin-to-cash') {
        if (wallet.balance < amount) {
            utils.alert.error('Insufficient coin balance');
            return;
        }
        
        // Convert coins to cash
        const cashAmount = amount * 0.5;
        window.database.wallets.updateBalance(walletId, wallet.balance - amount);
        
        window.database.transactions.create({
            accountNumber: wallet.walletAddress,
            amount: cashAmount,
            type: 'exchange',
            exchangeType: 'coin-to-cash',
            description: `Exchange ${amount.toFixed(8)} PIL to ${utils.format.currencyNGN(cashAmount)}`,
            status: 'completed'
        });
        
        utils.alert.success(`Exchanged ${amount.toFixed(8)} PIL to ${utils.format.currencyNGN(cashAmount)}`);
    } else {
        // Convert cash to coins (would need cash balance - simplified)
        const coinAmount = amount / 0.5;
        window.database.wallets.updateBalance(walletId, wallet.balance + coinAmount);
        
        window.database.transactions.create({
            accountNumber: wallet.walletAddress,
            amount: amount,
            type: 'exchange',
            exchangeType: 'cash-to-coin',
            description: `Exchange ${utils.format.currencyNGN(amount)} to ${coinAmount.toFixed(8)} PIL`,
            status: 'completed'
        });
        
        utils.alert.success(`Exchanged ${utils.format.currencyNGN(amount)} to ${coinAmount.toFixed(8)} PIL`);
    }
    
    document.getElementById('exchangeForm').reset();
    loadExchange();
    loadWallets();
    loadDashboardStats();
}

function creditAccount(accountId) {
    const amount = prompt('Enter coins to credit:');
    if (!amount || isNaN(amount)) return;
    
    const amountValue = parseFloat(amount);
    const account = window.database.mining.get(accountId);
    
    if (account) {
        window.database.mining.update(accountId, amountValue);
        
        // Update wallet balance
        const wallet = window.database.wallets.getAll().find(w => w.miningId === accountId);
        if (wallet) {
            window.database.wallets.updateBalance(wallet.id, wallet.balance + amountValue);
        }
        
        utils.alert.success(`Account credited with ${amountValue.toFixed(8)} PIL`);
        loadMining();
        loadWallets();
        loadDashboardStats();
    }
}

function loadTransactions() {
    const db = window.database.get();
    const transactions = db.transactions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const transactionsDiv = document.getElementById('transactionsList');
    if (!transactionsDiv) return;
    
    if (transactions.length === 0) {
        transactionsDiv.innerHTML = '<p class="no-data">No transactions found</p>';
        return;
    }
    
    transactionsDiv.innerHTML = `
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Wallet</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                ${transactions.slice(0, 50).map(t => `
                    <tr>
                        <td>${utils.format.dateTime(t.createdAt)}</td>
                        <td><code style="font-size: 11px;">${t.accountNumber.substring(0, 16)}...</code></td>
                        <td><span class="badge ${t.type === 'credit' ? 'success' : 'info'}">${t.type.toUpperCase()}</span></td>
                        <td>${t.description}</td>
                        <td>${t.type === 'exchange' && t.exchangeType === 'coin-to-cash' ? utils.format.currencyNGN(t.amount) : t.amount.toFixed(8) + ' PIL'}</td>
                        <td><span class="badge success">${t.status}</span></td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

function startMiningSimulation() {
    // Simulate mining for all active accounts
    miningInterval = setInterval(() => {
        const db = window.database.get();
        const miningAccounts = db.mining.filter(m => m.status === 'active');
        
        miningAccounts.forEach(account => {
            // Mine random amount based on rate
            const mined = 0.000000001 * Math.random() * 1000000;
            
            // Only update if significant amount mined
            if (mined > 0.00000001) {
                window.database.mining.update(account.id, mined);
                
                // Update corresponding wallet
                const wallet = window.database.wallets.getAll().find(w => w.miningId === account.id);
                if (wallet) {
                    window.database.wallets.updateBalance(wallet.id, wallet.balance + mined);
                }
            }
        });
        
        // Update dashboard if overview is visible
        const overviewSection = document.getElementById('overview');
        if (overviewSection && overviewSection.classList.contains('active')) {
            loadDashboardStats();
        }
        
        // Update mining section if visible
        const miningSection = document.getElementById('mining');
        if (miningSection && miningSection.classList.contains('active')) {
            loadMining();
        }
        
    }, 1000); // Update every second
}

function searchAccounts() {
    loadAccounts();
}

function viewAccount(accountId) {
    utils.alert.info('Account details view - Coming soon');
}

function openCustomerPortal() {
    utils.alert.info('Customer portal - Create separate customer portal file');
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        if (miningInterval) {
            clearInterval(miningInterval);
        }
        window.location.href = '../index.html';
    }
}